package com.alte.notes

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class NotesWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val note = NotesStore(context).all().firstOrNull()
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_notes)
            views.setTextViewText(R.id.widget_title, note?.title?.ifBlank { "Без названия" } ?: "Твои мысли — под рукой")
            views.setTextViewText(R.id.widget_body, note?.body?.take(90) ?: "Нажми, чтобы создать заметку")
            val intent = PendingIntent.getActivity(context,0,Intent(context,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_title,intent); views.setOnClickPendingIntent(R.id.widget_body,intent)
            manager.updateAppWidget(id,views)
        }
    }
    companion object { fun refresh(context: Context) { val m=AppWidgetManager.getInstance(context); val ids=m.getAppWidgetIds(ComponentName(context,NotesWidgetProvider::class.java)); NotesWidgetProvider().onUpdate(context,m,ids) } }
}
