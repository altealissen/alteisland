package com.alte.notes

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("notes_reminders","Заметки и напоминания",NotificationManager.IMPORTANCE_DEFAULT))
        val title = intent.getStringExtra("title") ?: "Напоминание Alte Notes"
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context,"notes_reminders") else Notification.Builder(context)
        manager.notify(intent.getLongExtra("id",0).toInt(), notification.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText("Пора вернуться к своей заметке").setAutoCancel(true).build())
    }
}
