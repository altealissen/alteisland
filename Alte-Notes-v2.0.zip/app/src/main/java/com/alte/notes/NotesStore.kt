package com.alte.notes

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

data class Note(
    val id: Long, val title: String, val body: String, val tags: String,
    val attachment: String, val updated: Long, val reminder: Long, val favorite: Boolean,
    val groupId: Long = 0L, val kind: String = "NOTE", val language: String = "text",
    val pinned: Boolean = false, val deleted: Boolean = false
)
data class NoteGroup(val id: Long, val name: String, val color: String, val parentId: Long)

/** Keeps the original SQLite database and upgrades it in-place to avoid losing existing notes. */
class NotesStore(context: Context) : SQLiteOpenHelper(context, "alte_notes.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,body TEXT NOT NULL,tags TEXT NOT NULL DEFAULT '',attachment TEXT NOT NULL DEFAULT '',updated INTEGER NOT NULL,reminder INTEGER NOT NULL DEFAULT 0,favorite INTEGER NOT NULL DEFAULT 0,group_id INTEGER NOT NULL DEFAULT 0,kind TEXT NOT NULL DEFAULT 'NOTE',language TEXT NOT NULL DEFAULT 'text',pinned INTEGER NOT NULL DEFAULT 0,deleted INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE note_groups(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,color TEXT NOT NULL DEFAULT '#DF8063',parent_id INTEGER NOT NULL DEFAULT 0)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            listOf("group_id INTEGER NOT NULL DEFAULT 0", "kind TEXT NOT NULL DEFAULT 'NOTE'", "language TEXT NOT NULL DEFAULT 'text'", "pinned INTEGER NOT NULL DEFAULT 0", "deleted INTEGER NOT NULL DEFAULT 0").forEach { db.execSQL("ALTER TABLE notes ADD COLUMN $it") }
        }
        if (oldVersion < 3) db.execSQL("CREATE TABLE IF NOT EXISTS note_groups(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,color TEXT NOT NULL DEFAULT '#DF8063',parent_id INTEGER NOT NULL DEFAULT 0)")
    }
    private fun read(c: android.database.Cursor) = Note(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getLong(5),c.getLong(6),c.getInt(7)==1,c.getLong(8),c.getString(9),c.getString(10),c.getInt(11)==1,c.getInt(12)==1)
    fun all(includeDeleted: Boolean = false): List<Note> {
        val out= mutableListOf<Note>(); val where=if(includeDeleted) "" else "WHERE deleted=0"
        readableDatabase.rawQuery("SELECT * FROM notes $where ORDER BY pinned DESC,favorite DESC,updated DESC",null).use { c -> while(c.moveToNext()) out+=read(c) }; return out
    }
    fun save(n: Note): Long {
        val v=ContentValues().apply { put("title",n.title);put("body",n.body);put("tags",n.tags);put("attachment",n.attachment);put("updated",System.currentTimeMillis());put("reminder",n.reminder);put("favorite",if(n.favorite)1 else 0);put("group_id",n.groupId);put("kind",n.kind);put("language",n.language);put("pinned",if(n.pinned)1 else 0);put("deleted",if(n.deleted)1 else 0) }
        return if(n.id==0L) writableDatabase.insertOrThrow("notes",null,v) else { writableDatabase.update("notes",v,"id=?", arrayOf(n.id.toString())); n.id }
    }
    fun trash(id:Long) { writableDatabase.execSQL("UPDATE notes SET deleted=1,updated=? WHERE id=?", arrayOf(System.currentTimeMillis(),id)) }
    fun restore(id:Long) { writableDatabase.execSQL("UPDATE notes SET deleted=0,updated=? WHERE id=?", arrayOf(System.currentTimeMillis(),id)) }
    fun deleteForever(id:Long) { writableDatabase.delete("notes","id=?",arrayOf(id.toString())) }
    fun groups():List<NoteGroup> { val a= mutableListOf<NoteGroup>(); readableDatabase.rawQuery("SELECT id,name,color,parent_id FROM note_groups ORDER BY name",null).use { c->while(c.moveToNext()) a+=NoteGroup(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3)) }; return a }
    fun saveGroup(name:String,color:String="#DF8063",parentId:Long=0):Long { val v=ContentValues().apply {put("name",name);put("color",color);put("parent_id",parentId)};return writableDatabase.insertOrThrow("note_groups",null,v) }
    fun renameGroup(id:Long,name:String) { writableDatabase.execSQL("UPDATE note_groups SET name=? WHERE id=?",arrayOf(name,id)) }
    fun deleteGroup(id:Long) { writableDatabase.beginTransaction();try { writableDatabase.execSQL("UPDATE notes SET group_id=0 WHERE group_id=?",arrayOf(id));writableDatabase.delete("note_groups","id=?",arrayOf(id.toString()));writableDatabase.setTransactionSuccessful() } finally { writableDatabase.endTransaction() } }
    fun exportJson():String { val ns=JSONArray(); all(true).forEach { n->ns.put(JSONObject().apply {put("id",n.id);put("title",n.title);put("body",n.body);put("tags",n.tags);put("attachment",n.attachment);put("updated",n.updated);put("reminder",n.reminder);put("favorite",n.favorite);put("groupId",n.groupId);put("kind",n.kind);put("language",n.language);put("pinned",n.pinned);put("deleted",n.deleted)}) }; val gs=JSONArray();groups().forEach { g->gs.put(JSONObject().apply {put("id",g.id);put("name",g.name);put("color",g.color);put("parentId",g.parentId)}) }; return JSONObject().put("format","alte-notes-backup").put("version",3).put("notes",ns).put("groups",gs).toString(2) }
    fun importJson(raw:String):Int { val root=JSONObject(raw);require(root.optString("format")=="alte-notes-backup") {"Неверный формат backup"};val a=root.getJSONArray("notes");var count=0;val groupMap=mutableMapOf<Long,Long>();writableDatabase.beginTransaction();try { val gs=root.optJSONArray("groups");if(gs!=null) for(i in 0 until gs.length()){val g=gs.getJSONObject(i);groupMap[g.optLong("id")]=saveGroup(g.optString("name"),g.optString("color","#DF8063"),0)};for(i in 0 until a.length()){val o=a.getJSONObject(i);val oldGroup=o.optLong("groupId");save(Note(0,o.optString("title"),o.optString("body"),o.optString("tags"),o.optString("attachment"),o.optLong("updated",System.currentTimeMillis()),o.optLong("reminder"),o.optBoolean("favorite"),groupMap[oldGroup]?:0L,o.optString("kind","NOTE"),o.optString("language","text"),o.optBoolean("pinned"),o.optBoolean("deleted")));count++};writableDatabase.setTransactionSuccessful() } finally {writableDatabase.endTransaction()};return count }
}
