package com.alte.notes

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import org.json.JSONObject
import java.io.File
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Calendar
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private val Bg=Color(0xFF111111); private val Surface=Color(0xFF191919); private val Raised=Color(0xFF242424)
private val MainText=Color(0xFFF0F0EA); private val Muted=Color(0xFFA5A59D); private val Accent=Color(0xFFDF8063); private val Line=Color(0xFF303030)

class MainActivity:FragmentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent { AlteNotesApp() }} }

@Composable private fun Panel(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit){ Column(modifier.background(Surface,RoundedCornerShape(14.dp)).padding(15.dp),content=content) }

@Composable fun AlteNotesApp(){
    val context= LocalContext.current; val store= remember { NotesStore(context) }
    var notes by remember { mutableStateOf(store.all()) }; var trash by remember { mutableStateOf(store.all(true).filter{it.deleted}) }; var groups by remember { mutableStateOf(store.groups()) }
    var section by remember { mutableStateOf("Все заметки") }; var query by remember { mutableStateOf("") }
    var editor by remember { mutableStateOf(false) }; var currentId by remember { mutableLongStateOf(0L) }; var codeMode by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }; var body by remember { mutableStateOf("") }; var tags by remember { mutableStateOf("") }; var attachment by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("Kotlin") }; var groupId by remember { mutableLongStateOf(0L) }; var favorite by remember { mutableStateOf(false) }; var pinned by remember { mutableStateOf(false) }; var reminder by remember { mutableLongStateOf(0L) }
    var mdPreview by remember { mutableStateOf(false) }; var settings by remember { mutableStateOf(false) }; var ai by remember { mutableStateOf(false) }; var groupDialog by remember { mutableStateOf(false) }; var groupName by remember { mutableStateOf("") }
    var pinDialog by remember { mutableStateOf(false) }; var pin by remember { mutableStateOf("") }; var pinInput by remember { mutableStateOf("") }; var locked by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }; var recording by remember { mutableStateOf(false) }
    fun refresh(){ notes=store.all();trash=store.all(true).filter{it.deleted};groups=store.groups();NotesWidgetProvider.refresh(context) }
    fun openNote(n:Note?=null,asCode:Boolean=false){ currentId=n?.id?:0L;title=n?.title.orEmpty();body=n?.body.orEmpty();tags=n?.tags.orEmpty();attachment=n?.attachment.orEmpty();language=n?.language?.takeIf{it!="text"}?:"Kotlin";groupId=n?.groupId?:0L;favorite=n?.favorite?:false;pinned=n?.pinned?:false;reminder=n?.reminder?:0L;codeMode=asCode||n?.kind=="CODE";mdPreview=false;editor=true }
    fun persist(close:Boolean=false){ if(title.isBlank()&&body.isBlank()) { if(close) editor=false;return }; val id=store.save(Note(currentId,title,body,tags,attachment,System.currentTimeMillis(),reminder,favorite,groupId,if(codeMode)"CODE" else "NOTE",language,pinned,false));currentId=id;refresh();if(close)editor=false }
    LaunchedEffect(editor,title,body,tags,attachment,language,groupId,favorite,pinned,reminder){ if(editor&&(title.isNotBlank()||body.isNotBlank())) { kotlinx.coroutines.delay(750);persist(false) } }

    val attachPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri:Uri?->uri?.let{try{context.contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};attachment=it.toString()} }
    val backupOut=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri->uri?.let{val bytes=ByteArrayOutputStream();ZipOutputStream(bytes).use{z->z.putNextEntry(ZipEntry("manifest.json"));z.write(store.exportJson().toByteArray());z.closeEntry()};context.contentResolver.openOutputStream(it)?.use{out->out.write(bytes.toByteArray())};Toast.makeText(context,"ZIP backup создан",Toast.LENGTH_LONG).show()} }
    val backupIn=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            try {
                val raw = context.contentResolver.openInputStream(it)?.use { input ->
                    val bytes = input.readBytes()
                    if (bytes.size >= 2 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) {
                        var manifest = ""
                        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
                            while (true) {
                                val entry = zip.nextEntry ?: break
                                if (entry.name == "manifest.json") manifest = zip.readBytes().toString(Charsets.UTF_8)
                            }
                        }
                        manifest
                    } else bytes.toString(Charsets.UTF_8)
                } ?: error("Пустой файл")
                val count = store.importJson(raw)
                refresh()
                Toast.makeText(context, "Импортировано заметок: $count", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Backup не импортирован: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
    val audioPermission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){ok->if(ok){try{val f=File(context.filesDir,"voice_${System.currentTimeMillis()}.m4a");recorder=createRecorder(context).apply{setAudioSource(MediaRecorder.AudioSource.MIC);setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);setAudioEncoder(MediaRecorder.AudioEncoder.AAC);setOutputFile(f.absolutePath);prepare();start()};attachment=f.absolutePath;recording=true}catch(e:Exception){Toast.makeText(context,"Не удалось начать запись",Toast.LENGTH_SHORT).show()}}}

    MaterialTheme(colorScheme=darkColorScheme(primary=Accent,secondary=Accent,background=Bg,surface=Surface,onBackground=MainText,onSurface=MainText)) {
      if(locked){Column(Modifier.fillMaxSize().background(Bg).padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){Text("ALTE NOTES",color=Accent,letterSpacing=4.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(20.dp));Text("Приложение заблокировано",fontSize=22.sp);OutlinedTextField(pinInput,{pinInput=it.filter(Char::isDigit).take(8)},label={Text("PIN-код")});Button(onClick={if(pinInput.isNotEmpty()&&securePin(pinInput)==context.getSharedPreferences("alte_secure",0).getString("pin_hash",null)){locked=false;pinInput=""}else Toast.makeText(context,"Неверный PIN",Toast.LENGTH_SHORT).show()}){Text("Разблокировать")};TextButton(onClick={biometric(context){locked=false}}){Text("Биометрия")}}}
      else if(editor){
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().padding(horizontal=18.dp, vertical=10.dp)){
          Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={persist(true)}){Icon(Icons.Default.ArrowBack,null,tint=MainText)};Text(if(codeMode)"Alte Code" else "Заметка",Modifier.weight(1f),color=MainText,fontWeight=FontWeight.SemiBold);IconButton(onClick={favorite=!favorite}){Icon(if(favorite)Icons.Default.Star else Icons.Default.StarBorder,null,tint=Accent)};IconButton(onClick={pinned=!pinned}){Icon(Icons.Default.PushPin,null,tint=if(pinned)Accent else Muted)};TextButton(onClick={persist(true)}){Text("Готово",color=Accent)}}
          Panel(Modifier.weight(1f).fillMaxWidth()){
            BasicTextField(title,{title=it},Modifier.fillMaxWidth(),textStyle=androidx.compose.ui.text.TextStyle(color=MainText,fontSize=25.sp,fontWeight=FontWeight.SemiBold),decorationBox={inner->if(title.isEmpty())Text(if(codeMode)"Имя файла" else "Название",color=Muted,fontSize=25.sp);inner()})
            Spacer(Modifier.height(14.dp));HorizontalDivider(color=Line);Spacer(Modifier.height(12.dp))
            if(codeMode){Row(verticalAlignment=Alignment.CenterVertically){Text("Язык",color=Muted,fontSize=12.sp);Spacer(Modifier.width(8.dp));var expanded by remember{mutableStateOf(false)};Box{TextButton(onClick={expanded=true}){Text(language,color=Accent)};DropdownMenu(expanded,{expanded=false}){listOf("Kotlin","Java","Python","JavaScript","TypeScript","HTML","CSS","JSON","XML","C","C++","C#","PHP","SQL","Bash","Markdown","YAML","Rust","Go").forEach{DropdownMenuItem(text={Text(it)},onClick={language=it;expanded=false})}}}}}
            if(mdPreview&&!codeMode) Text(body,color=MainText,fontSize=16.sp,modifier=Modifier.weight(1f).fillMaxWidth()) else BasicTextField(body,{body=it},Modifier.weight(1f).fillMaxWidth(),textStyle=androidx.compose.ui.text.TextStyle(color=MainText,fontSize=if(codeMode)14.sp else 16.sp,lineHeight=24.sp,fontFamily=if(codeMode)FontFamily.Monospace else FontFamily.Default),decorationBox={inner->if(body.isEmpty())Text(if(codeMode)"// Начни писать код…" else "Запиши свою мысль…\n\nПоддерживается Markdown",color=Muted);inner()})
            Spacer(Modifier.height(10.dp));HorizontalDivider(color=Line);Spacer(Modifier.height(8.dp))
            OutlinedTextField(tags,{tags=it},Modifier.fillMaxWidth(),label={Text("Теги")},singleLine=true)
            var groupExpanded by remember{mutableStateOf(false)};Box{TextButton(onClick={groupExpanded=true}){Text("Группа: ${groups.firstOrNull{it.id==groupId}?.name?:"Без группы"}",color=Accent)};DropdownMenu(groupExpanded,{groupExpanded=false}){DropdownMenuItem(text={Text("Без группы")},onClick={groupId=0;groupExpanded=false});groups.forEach{g->DropdownMenuItem(text={Text(g.name)},onClick={groupId=g.id;groupExpanded=false})}}}
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){TextButton(onClick={attachPicker.launch(arrayOf("*/*"))}){Icon(Icons.Default.AttachFile,null);Text("Файл")};TextButton(onClick={if(recording){try{recorder?.stop();recorder?.release()}catch(_:Exception){};recorder=null;recording=false}else audioPermission.launch(Manifest.permission.RECORD_AUDIO)}){Icon(if(recording)Icons.Default.Stop else Icons.Default.Mic,null);Text(if(recording)"Стоп" else "Голос")};TextButton(onClick={scheduleReminder(context,title){reminder=it}}){Icon(Icons.Default.Notifications,null);Text("Напомнить")};if(!codeMode)TextButton(onClick={mdPreview=!mdPreview}){Text(if(mdPreview)"Править" else "Markdown")}}
            if(attachment.isNotBlank())Text("Вложение: ${attachment.substringAfterLast('/')}",color=Muted,fontSize=11.sp,maxLines=1)
            if(reminder>0)Text("Напоминание: ${java.text.SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(reminder)}",color=Accent,fontSize=12.sp)
          }
        }
      }else{
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().padding(horizontal=18.dp)){
          Row(Modifier.fillMaxWidth().padding(top=14.dp,bottom=18.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("ALTE NOTES",color=Accent,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=3.sp);AnimatedContent(section,label={"section"}){Text(if(it=="Все заметки")greeting() else it,color=MainText,fontSize=24.sp,fontWeight=FontWeight.Medium)}};IconButton(onClick={ai=true}){Icon(Icons.Default.AutoAwesome,null,tint=Accent)};IconButton(onClick={settings=true}){Icon(Icons.Default.Settings,null,tint=MainText)}}
          Row(Modifier.fillMaxWidth().background(Surface,RoundedCornerShape(12.dp)).padding(horizontal=12.dp,vertical=11.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Search,null,tint=Muted);Spacer(Modifier.width(8.dp));BasicTextField(query,{query=it},Modifier.weight(1f),textStyle=androidx.compose.ui.text.TextStyle(color=MainText),decorationBox={inner->if(query.isEmpty())Text("Поиск заметок и файлов",color=Muted);inner()})}
          Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Все заметки","Группы","Code","Избранное","Недавние","Архив","Корзина").forEach{label->val short=when(label){"Все заметки"->"Все";"Избранное"->"★";"Недавние"->"Недав.";else->label};TextButton(onClick={section=label},contentPadding=PaddingValues(horizontal=8.dp,vertical=3.dp),colors=ButtonDefaults.textButtonColors(contentColor=if(section==label)Accent else Muted)){Text(short,fontSize=11.sp,fontWeight=if(section==label)FontWeight.Bold else FontWeight.Normal)}}}
          if(section=="Группы"){
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("Группы заметок",Modifier.weight(1f),fontSize=18.sp,fontWeight=FontWeight.SemiBold);TextButton(onClick={groupDialog=true}){Icon(Icons.Default.Add,null);Text("Создать")}}
            LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(groups,key={it.id}){g->Panel(Modifier.fillMaxWidth().clickable{section="Все заметки";query=""}){Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Folder,null,tint=Accent);Spacer(Modifier.width(10.dp));Text(g.name,Modifier.weight(1f),color=MainText);Text("${notes.count{it.groupId==g.id}}",color=Muted);IconButton(onClick={store.deleteGroup(g.id);refresh()}){Icon(Icons.Default.Delete,null,tint=Muted)}}}}}
          }else{
            val shown=when(section){"Корзина"->trash;"Избранное"->notes.filter{it.favorite};"Code"->notes.filter{it.kind=="CODE"};"Архив"->emptyList();"Недавние"->notes.take(20);else->notes}.filter{query.isBlank()||it.title.contains(query,true)||it.body.contains(query,true)||it.tags.contains(query,true)}
            Row(Modifier.fillMaxWidth().padding(vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Text(section,Modifier.weight(1f),fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text("${shown.size}",color=Muted,fontSize=12.sp)}
            if(shown.isEmpty())Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text("✳",fontSize=34.sp,color=Accent);Spacer(Modifier.height(8.dp));Text(if(section=="Корзина")"Корзина пуста" else "Здесь пока тихо",color=MainText,fontSize=18.sp);Text("Создай заметку или файл кода",color=Muted,fontSize=13.sp)}}
            else LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=12.dp)){items(shown,key={it.id}){n->Panel(Modifier.fillMaxWidth().clickable(enabled=section!="Корзина"){openNote(n)}){Row(verticalAlignment=Alignment.CenterVertically){if(n.kind=="CODE")Icon(Icons.Default.Code,null,tint=Accent) else Icon(Icons.Default.Description,null,tint=Muted);Spacer(Modifier.width(9.dp));Text(n.title.ifBlank{if(n.kind=="CODE")"Безымянный файл" else "Без названия"},Modifier.weight(1f),color=MainText,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis);if(n.pinned)Icon(Icons.Default.PushPin,null,tint=Accent);if(n.favorite)Icon(Icons.Default.Star,null,tint=Accent)};Spacer(Modifier.height(6.dp));Text(n.body.ifBlank{"Нет содержимого"},color=Muted,fontSize=13.sp,maxLines=2,overflow=TextOverflow.Ellipsis);Spacer(Modifier.height(8.dp));Row(verticalAlignment=Alignment.CenterVertically){Text(if(n.kind=="CODE")n.language else n.tags,color=Accent,fontSize=11.sp,Modifier.weight(1f));Text(java.text.SimpleDateFormat("dd MMM · HH:mm",Locale.getDefault()).format(n.updated),color=Muted,fontSize=10.sp);if(section=="Корзина"){TextButton(onClick={store.restore(n.id);refresh()}){Text("Вернуть")};TextButton(onClick={store.deleteForever(n.id);refresh()}){Text("Удалить")}}else IconButton(onClick={store.trash(n.id);refresh()}){Icon(Icons.Default.DeleteOutline,null,tint=Muted)}}}}}
          }
          Row(Modifier.fillMaxWidth().padding(vertical=10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(onClick={openNote()},Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Accent,contentColor=Color.Black)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("Заметка")};OutlinedButton(onClick={openNote(asCode=true)},Modifier.weight(1f)){Icon(Icons.Default.Code,null);Spacer(Modifier.width(6.dp));Text("Code")}}
        }
      }
    }
    if(groupDialog)AlertDialog(onDismissRequest={groupDialog=false},title={Text("Новая группа")},text={OutlinedTextField(groupName,{groupName=it},label={Text("Название")})},confirmButton={TextButton(onClick={if(groupName.isNotBlank()){store.saveGroup(groupName.trim());groupName="";refresh()};groupDialog=false}){Text("Создать")}},dismissButton={TextButton(onClick={groupDialog=false}){Text("Отмена")}})
    if(ai)AlertDialog(onDismissRequest={ai=false},title={Text("Alte AI · автономные инструменты")},text={Text("Это локальные алгоритмы обработки текста, не генеративная нейросеть. Для LLM предусмотрено отдельное подключение локального runtime.")},confirmButton={TextButton(onClick={val result=summary(body.ifBlank{notes.firstOrNull()?.body.orEmpty()});if(!editor)openNote();title="Краткое содержание";body=result;ai=false}){Text("Сократить")}},dismissButton={TextButton(onClick={val result=checklist(body.ifBlank{notes.firstOrNull()?.body.orEmpty()});if(!editor)openNote();title="Список задач";body=result;ai=false}){Text("В чек-лист")}})
    if(settings)AlertDialog(onDismissRequest={settings=false},title={Text("Настройки Alte Notes")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Локальное хранение · без регистрации и облачной синхронизации",color=Muted);OutlinedButton(onClick={backupOut.launch("Alte-Notes-backup.zip")},Modifier.fillMaxWidth()){Icon(Icons.Default.Backup,null);Text("Создать ZIP backup")};OutlinedButton(onClick={backupIn.launch(arrayOf("application/zip","application/json","*/*"))},Modifier.fillMaxWidth()){Icon(Icons.Default.FileOpen,null);Text("Восстановить backup")};OutlinedButton(onClick={pinDialog=true},Modifier.fillMaxWidth()){Icon(Icons.Default.Password,null);Text("Установить PIN")};OutlinedButton(onClick={biometric(context){locked=true;settings=false}},Modifier.fillMaxWidth()){Icon(Icons.Default.Fingerprint,null);Text("Заблокировать биометрией")};Text("Редактор Code использует локальный моноширинный ввод; расширенная IDE-функциональность ещё не подключена.",fontSize=12.sp,color=Muted)}},confirmButton={TextButton(onClick={settings=false}){Text("Закрыть")}})
    if(pinDialog)AlertDialog(onDismissRequest={pinDialog=false;pin=""},title={Text("Новый PIN")},text={OutlinedTextField(pin,{pin=it.filter(Char::isDigit).take(8)},label={Text("4–8 цифр")})},confirmButton={TextButton(onClick={if(pin.length>=4){context.getSharedPreferences("alte_secure",0).edit().putString("pin_hash",securePin(pin)).apply();Toast.makeText(context,"PIN установлен",Toast.LENGTH_SHORT).show();pinDialog=false;pin=""}else Toast.makeText(context,"Минимум 4 цифры",Toast.LENGTH_SHORT).show()}){Text("Сохранить")}},dismissButton={TextButton(onClick={pinDialog=false}){Text("Отмена")}})
}

@Suppress("DEPRECATION")
private fun createRecorder(context:Context):MediaRecorder = if(Build.VERSION.SDK_INT>=31) MediaRecorder(context) else MediaRecorder()
private fun greeting():String { val h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);return when(h){in 5..11->"Доброе утро!";in 12..17->"Что сегодня создадим?";else->"Добрый вечер."} }
private fun summary(s:String)=s.trim().split(Regex("(?<=[.!?])\\s+|\\n")).filter{it.isNotBlank()}.take(3).joinToString("\n").ifBlank{"Добавь текст для обработки."}
private fun checklist(s:String)=s.split(Regex("[.!?\\n]+ ")).map{it.trim()}.filter{it.isNotBlank()}.joinToString("\n"){"- [ ] $it"}.ifBlank{"- [ ] Добавь текст для обработки"}
private fun securePin(pin:String):String { val salt="alte-notes-local-v2";return java.security.MessageDigest.getInstance("SHA-256").digest("$salt:$pin".toByteArray()).joinToString(""){"%02x".format(it)} }
private fun biometric(context:Context,onSuccess:()->Unit){val a=context as? FragmentActivity?:return;val prompt=BiometricPrompt(a,ContextCompat.getMainExecutor(context),object:BiometricPrompt.AuthenticationCallback(){override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){onSuccess()}});prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Alte Notes").setSubtitle("Подтверди личность").setNegativeButtonText("Отмена").build())}
private fun scheduleReminder(context:Context,title:String,onSet:(Long)->Unit){val now=Calendar.getInstance();DatePickerDialog(context,{_,y,m,d->TimePickerDialog(context,{_,h,min->val c=Calendar.getInstance().apply{set(y,m,d,h,min,0);set(Calendar.MILLISECOND,0)};val at=c.timeInMillis;val intent=Intent(context,ReminderReceiver::class.java).putExtra("title",title.ifBlank{"Напоминание Alte Notes"}).putExtra("id",at);val pi=PendingIntent.getBroadcast(context,at.toInt(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val alarm=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager;if(Build.VERSION.SDK_INT>=23)alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi)else alarm.set(AlarmManager.RTC_WAKEUP,at,pi);onSet(at)},now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true).show()},now.get(Calendar.YEAR),now.get(Calendar.MONTH),now.get(Calendar.DAY_OF_MONTH)).show()}
