package com.alte.allconvertor

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.format.DateFormat
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App() }
    }
}

enum class St { Idle, Run, Done, Fail }

@Composable
fun App() {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize()) { Home() } }
}

fun apkName(ctx: Context, uri: android.net.Uri): String {
    val raw = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "app"
    val base = raw.removeSuffix(".zip").replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifEmpty { "app" }
    return base + "_" + SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(Date()) + ".apk"
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("alte", 0) }
    var token by remember { mutableStateOf(prefs.getString("t", "") ?: "") }
    var editing by remember { mutableStateOf(token.isEmpty()) }
    var st by remember { mutableStateOf(St.Idle) }
    var step by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    var apk by remember { mutableStateOf<SavedApk?>(null) }
    var history by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            st = St.Run; step = 0
            scope.launch(Dispatchers.IO) {
                try {
                    val gh = Gh(token, ctx.assets.open("builder.yml").bufferedReader().readText())
                    gh.setup()
                    val dir = File(ctx.cacheDir, "apk").apply { mkdirs() }
                    val out = File(dir, "tmp-${System.currentTimeMillis()}.apk")
                    gh.build({ ctx.contentResolver.openInputStream(uri)!! }, out) { step = it }
                    apk = ApkStore.save(ctx, out, apkName(ctx, uri)); st = St.Done
                } catch (e: Exception) { msg = e.message ?: "Ошибка"; st = St.Fail }
            }
        }
    }

    if (history) {
        BackHandler { history = false }
        History(onBack = { history = false })
        return
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Alte All Convertor", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Text("ZIP с проектом → готовый APK", style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        AnimatedVisibility(editing, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            var tmp by remember { mutableStateOf(token) }
            Card(shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("GitHub-токен", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("GitHub → Settings → Developer settings → Personal access tokens (classic). Отметь права repo и workflow.",
                        style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(tmp, { tmp = it }, singleLine = true, label = { Text("ghp_...") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { token = tmp.trim(); prefs.edit().putString("t", token).apply(); editing = false },
                        enabled = tmp.isNotBlank()) { Text("Сохранить") }
                }
            }
        }

        AnimatedContent(st, Modifier.weight(1f), label = "stage", transitionSpec = {
            (slideInVertically { it / 8 } + fadeIn(tween(350))) togetherWith fadeOut(tween(200))
        }) { s ->
            when (s) {
                St.Idle -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(36.dp),
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
                    val inf = rememberInfiniteTransition(label = "p")
                    val sc by inf.animateFloat(1f, 1.15f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)) {
                        Box(Modifier.scale(sc).size(96.dp).background(MaterialTheme.colorScheme.primary, CircleShape),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Build, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onPrimary)
                        }
                        Text("Выбери ZIP с Android-проектом", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        ExtendedFloatingActionButton(
                            onClick = { if (token.isEmpty()) editing = true else pick.launch(arrayOf("*/*")) },
                            icon = { Icon(Icons.Default.Add, null) }, text = { Text("Выбрать ZIP") })
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton({ history = true }) { Icon(Icons.Default.List, null); Spacer(Modifier.width(8.dp)); Text("История") }
                            TextButton({ editing = !editing }) { Icon(Icons.Default.Settings, null); Spacer(Modifier.width(8.dp)); Text("Токен") }
                        }
                    }
                }
                St.Run -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(36.dp),
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerHigh)) {
                    Column(Modifier.padding(28.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        listOf("Подготовка", "Загрузка ZIP", "Сборка в облаке", "Скачивание APK").forEachIndexed { i, name ->
                            val done = i < step; val cur = i == step
                            val bg by animateColorAsState(if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, label = "c")
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Box(Modifier.size(40.dp).background(bg, CircleShape), contentAlignment = Alignment.Center) {
                                    if (done) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.onPrimary)
                                    else if (cur) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                                }
                                Text(name, style = MaterialTheme.typography.titleMedium,
                                    fontWeight = if (cur) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                        Text("Сборка занимает 2–6 минут. Можно свернуть приложение.", style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                St.Done -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(36.dp),
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)) {
                        Icon(Icons.Default.CheckCircle, null, Modifier.size(80.dp), tint = MaterialTheme.colorScheme.tertiary)
                        Text("APK готов!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Сохранён в ${ApkStore.folderLabel()}", style = MaterialTheme.typography.bodyMedium)
                        Button(onClick = { apk?.let { ApkStore.install(ctx, it) } }) { Text("Установить") }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton({ history = true }) { Text("История") }
                            TextButton({ st = St.Idle }) { Text("Ещё один проект") }
                        }
                    }
                }
                St.Fail -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(36.dp),
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Icon(Icons.Default.Warning, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.error)
                        Text(msg, style = MaterialTheme.typography.bodyLarge)
                        Button({ st = St.Idle }) { Text("Назад") }
                    }
                }
            }
        }
    }
}

@Composable
fun History(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<SavedApk>?>(null) }
    var toDelete by remember { mutableStateOf<SavedApk?>(null) }

    fun reload() { scope.launch { items = withContext(Dispatchers.IO) { ApkStore.list(ctx) } } }
    LaunchedEffect(Unit) { reload() }

    toDelete?.let { a ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Удалить APK?") },
            text = { Text(a.name) },
            confirmButton = {
                TextButton({
                    scope.launch { withContext(Dispatchers.IO) { ApkStore.delete(ctx, a) }; toDelete = null; reload() }
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton({ toDelete = null }) { Text("Отмена") } }
        )
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("← Назад") }
        }
        Text("История APK", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(ApkStore.folderLabel(), style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        val list = items
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Пока пусто. Собранные APK появятся здесь.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(list, key = { it.uri.toString() }) { a ->
                    Card(shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerHigh)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(a.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                DateFormat.format("dd.MM.yyyy HH:mm", a.time).toString() + " · " + Formatter.formatShortFileSize(ctx, a.size),
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button({ ApkStore.install(ctx, a) }) { Text("Установить") }
                                TextButton({ toDelete = a }) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Удалить") }
                            }
                        }
                    }
                }
            }
        }
    }
}
