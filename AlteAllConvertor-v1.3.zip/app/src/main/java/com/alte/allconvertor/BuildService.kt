package com.alte.allconvertor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

data class UiState(val st: St = St.Idle, val step: Int = 0, val msg: String = "", val apk: SavedApk? = null)

object BuildState {
    val state = MutableStateFlow(UiState())
    fun reset() { state.value = UiState() }
}

/** Фоновая сборка: работает при свёрнутом приложении и выключенном экране, по окончании шлёт уведомление. */
class BuildService : Service() {
    private var worker: Thread? = null
    private val steps = listOf("Подготовка", "Загрузка ZIP", "Сборка в облаке", "Скачивание APK")

    companion object {
        private const val ACTION_CANCEL = "com.alte.allconvertor.CANCEL"
        private const val CH_PROGRESS = "progress"
        private const val CH_RESULT = "result"
        private const val ID_PROGRESS = 1
        private const val ID_RESULT = 2

        fun start(ctx: Context, uri: Uri) {
            BuildState.state.value = UiState(St.Run, 0)
            ctx.startForegroundService(
                Intent(ctx, BuildService::class.java).setData(uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) { worker?.interrupt(); return START_NOT_STICKY }
        val uri = intent?.data
        if (worker?.isAlive == true) return START_NOT_STICKY
        if (uri == null) { stopSelf(); return START_NOT_STICKY }
        createChannels()
        val n = progressNotification(0)
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(ID_PROGRESS, n)
        worker = Thread { runBuild(uri) }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun nm() = getSystemService(NotificationManager::class.java)

    private fun createChannels() {
        nm().createNotificationChannel(NotificationChannel(CH_PROGRESS, "Ход сборки", NotificationManager.IMPORTANCE_LOW))
        nm().createNotificationChannel(NotificationChannel(CH_RESULT, "Результат сборки", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun progressNotification(step: Int): Notification {
        val cancel = PendingIntent.getService(
            this, 1, Intent(this, BuildService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Alte All Convertor")
            .setContentText("${steps[step.coerceIn(0, 3)]}… (${step.coerceIn(0, 3) + 1}/4)")
            .setProgress(4, step.coerceIn(0, 3), false)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(openApp())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Отмена", cancel).build())
            .build()
    }

    private fun update(step: Int) {
        BuildState.state.value = UiState(St.Run, step)
        nm().notify(ID_PROGRESS, progressNotification(step))
    }

    private fun notifyDone(apk: SavedApk) {
        val view = PendingIntent.getActivity(
            this, 2,
            Intent(Intent.ACTION_VIEW).setDataAndType(apk.uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
            PendingIntent.FLAG_IMMUTABLE
        )
        nm().notify(ID_RESULT, Notification.Builder(this, CH_RESULT)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("APK готов")
            .setContentText("${apk.name} — сохранён в ${ApkStore.folderLabel()}")
            .setStyle(Notification.BigTextStyle().bigText("${apk.name}\nСохранён в ${ApkStore.folderLabel()}"))
            .setContentIntent(openApp()).setAutoCancel(true)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.stat_sys_download_done), "Установить", view).build())
            .build())
    }

    private fun notifyFail(text: String) {
        nm().notify(ID_RESULT, Notification.Builder(this, CH_RESULT)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("Сборка не удалась")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp()).setAutoCancel(true)
            .build())
    }

    private fun runBuild(uri: Uri) {
        val wl = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alte:build").apply { acquire(45 * 60 * 1000L) }
        try {
            val token = getSharedPreferences("alte", 0).getString("t", "").orEmpty()
            val gh = Gh(token, assets.open("builder.yml").bufferedReader().readText())
            update(0)
            gh.setup()
            val dir = File(cacheDir, "apk").apply { mkdirs() }
            val out = File(dir, "tmp-${System.currentTimeMillis()}.apk")
            gh.build({ contentResolver.openInputStream(uri)!! }, out) { update(it) }
            val apk = ApkStore.save(this, out, apkName(this, uri))
            BuildState.state.value = UiState(St.Done, apk = apk)
            notifyDone(apk)
        } catch (e: Exception) {
            val cancelled = e is InterruptedException || Thread.currentThread().isInterrupted
            if (cancelled) {
                BuildState.reset()
            } else {
                val m = e.message ?: "Ошибка"
                BuildState.state.value = UiState(St.Fail, msg = m)
                notifyFail(m)
            }
        } finally {
            if (wl.isHeld) wl.release()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }
}
