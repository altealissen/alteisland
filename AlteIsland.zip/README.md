# AlteIsland
Залейте этот zip в репозиторий как есть (не распаковывая). GitHub сам распакует и соберёт APK.
Скачать: Releases → AlteIsland.apk
