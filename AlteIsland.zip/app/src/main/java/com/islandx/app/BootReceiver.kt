package com.islandx.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.bool(c, Prefs.ENABLED, true) && Settings.canDrawOverlays(c)) {
            try { OverlayService.start(c) } catch (_: Throwable) {}
        }
    }
}
