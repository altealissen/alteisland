package com.islandx.app

import android.app.PendingIntent
import android.graphics.Bitmap
import android.media.session.MediaController
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

data class MusicState(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val playing: Boolean,
    val posMs: Long,
    val durMs: Long,
    val updatedAt: Long,
    val speed: Float
)

data class NotifState(
    val app: String,
    val title: String,
    val text: String,
    val icon: Bitmap?,
    val intent: PendingIntent?
)

data class TaxiState(
    val app: String,
    val title: String,
    val text: String,
    val etaMin: Int?,
    val startEta: Int?,
    val from: String,
    val to: String
)

/** Состояние таймера (общее для приложения и острова). */
object TimerState {
    var total = 0L
        private set
    var running = false
        private set
    var finished = false
        private set
    private var endAt = 0L
    private var paused = 0L

    fun active(): Boolean = total > 0L

    fun remaining(): Long =
        if (running) maxOf(0L, endAt - SystemClock.elapsedRealtime()) else paused

    fun start(ms: Long) {
        total = ms
        paused = ms
        endAt = SystemClock.elapsedRealtime() + ms
        running = true
        finished = false
    }

    fun toggle() {
        if (finished || total == 0L) return
        if (running) {
            paused = remaining()
            running = false
        } else {
            endAt = SystemClock.elapsedRealtime() + paused
            running = true
        }
    }

    fun add(ms: Long) {
        if (total == 0L || finished) return
        if (running) endAt += ms else paused += ms
        total += ms
    }

    fun reset() {
        total = 0L
        paused = 0L
        endAt = 0L
        running = false
        finished = false
    }

    fun finish() {
        running = false
        finished = true
        paused = 0L
    }
}

/** Мост между сервисом-слушателем уведомлений и оверлеем. */
object IslandBus {
    interface Sink {
        fun onChanged()
        fun onNotif(n: NotifState)
    }

    @Volatile var sink: Sink? = null
    @Volatile var music: MusicState? = null
    @Volatile var taxi: TaxiState? = null
    @Volatile var controller: MediaController? = null

    private val main = Handler(Looper.getMainLooper())

    fun setMusic(m: MusicState?, c: MediaController?) {
        music = m
        controller = c
        main.post { sink?.onChanged() }
    }

    fun setTaxi(t: TaxiState?) {
        taxi = t
        main.post { sink?.onChanged() }
    }

    fun postNotif(n: NotifState) {
        main.post { sink?.onNotif(n) }
    }
}
