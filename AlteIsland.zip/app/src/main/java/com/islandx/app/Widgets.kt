package com.islandx.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/** Иконки плеера, нарисованные кодом (без картинок). */
class IconView(ctx: Context, var type: Int) : View(ctx) {
    companion object {
        const val PLAY = 0
        const val PAUSE = 1
        const val NEXT = 2
        const val PREV = 3
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val path = Path()

    fun set(t: Int) {
        if (type != t) {
            type = t
            invalidate()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        when (type) {
            PLAY -> {
                path.reset()
                path.moveTo(w * .34f, h * .22f)
                path.lineTo(w * .78f, h * .5f)
                path.lineTo(w * .34f, h * .78f)
                path.close()
                c.drawPath(path, p)
            }
            PAUSE -> {
                c.drawRoundRect(w * .28f, h * .22f, w * .44f, h * .78f, 5f, 5f, p)
                c.drawRoundRect(w * .56f, h * .22f, w * .72f, h * .78f, 5f, 5f, p)
            }
            NEXT -> {
                path.reset()
                path.moveTo(w * .22f, h * .28f)
                path.lineTo(w * .62f, h * .5f)
                path.lineTo(w * .22f, h * .72f)
                path.close()
                c.drawPath(path, p)
                c.drawRect(w * .66f, h * .28f, w * .76f, h * .72f, p)
            }
            PREV -> {
                path.reset()
                path.moveTo(w * .78f, h * .28f)
                path.lineTo(w * .38f, h * .5f)
                path.lineTo(w * .78f, h * .72f)
                path.close()
                c.drawPath(path, p)
                c.drawRect(w * .24f, h * .28f, w * .34f, h * .72f, p)
            }
        }
    }
}

/** Анимированный эквалайзер. */
class EqView(ctx: Context) : View(ctx) {
    var active = false
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF4D6D") }

    override fun onDraw(c: Canvas) {
        val n = 4
        val gap = width * 0.12f
        val bw = (width - gap * (n - 1)) / n
        val t = SystemClock.uptimeMillis() / 170.0
        for (i in 0 until n) {
            val s = (0.5 + 0.5 * sin(t + i * 1.7)).toFloat()
            val f = if (active) 0.25f + 0.75f * s else 0.2f
            val bh = height * f
            val l = i * (bw + gap)
            c.drawRoundRect(l, (height - bh) / 2f, l + bw, (height + bh) / 2f, bw / 2f, bw / 2f, p)
        }
        if (active) postInvalidateOnAnimation()
    }
}

/** Тонкая полоса прогресса. */
class BarView(ctx: Context, fgColor: String) : View(ctx) {
    var value = 0f
        set(v) {
            val nv = v.coerceIn(0f, 1f)
            if (nv != field) {
                field = nv
                invalidate()
            }
        }
    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#40FFFFFF") }
    private val fgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor(fgColor) }

    override fun onDraw(c: Canvas) {
        val r = height / 2f
        c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, bgP)
        if (value > 0f) c.drawRoundRect(0f, 0f, width * value, height.toFloat(), r, r, fgP)
    }
}

/** Маршрут такси: точка А — машинка — точка Б, машинка плавно едет. */
class RouteView(ctx: Context) : View(ctx) {
    var progress = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    private var shown = 0f
    private val yellow = Color.parseColor("#FFD60A")
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#48484A"); strokeWidth = 7f; strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = yellow; strokeWidth = 7f; strokeCap = Paint.Cap.ROUND
    }
    private val dotA = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val dotB = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = yellow }
    private val car = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    override fun onDraw(c: Canvas) {
        val pad = height * 0.45f
        val y = height / 2f
        val x0 = pad
        val x1 = width - pad
        shown += (progress - shown) * 0.08f
        if (abs(progress - shown) > 0.002f) postInvalidateOnAnimation() else shown = progress
        c.drawLine(x0, y, x1, y, line)
        val cx = x0 + (x1 - x0) * shown
        c.drawLine(x0, y, cx, y, fill)
        c.drawCircle(x0, y, height * 0.11f, dotA)
        c.drawCircle(x1, y, height * 0.11f, dotB)
        car.textSize = height * 0.62f
        c.drawText("\uD83D\uDE95", cx, y + car.textSize * 0.34f, car)
    }
}
