package com.islandx.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.content.ContextCompat

/** Foreground-сервис, который держит остров поверх всех окон. */
class OverlayService : Service(), IslandView.Host, IslandBus.Sink {

    companion object {
        @Volatile var instance: OverlayService? = null
        private const val CH = "island_service"
        private const val ID = 1

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, OverlayService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var view: IslandView? = null
    private val handler = Handler(Looper.getMainLooper())

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applySettings() }

    private val ticker = object : Runnable {
        override fun run() {
            try { view?.tick() } catch (_: Throwable) {}
            handler.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startFg()
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        IslandBus.sink = this
        ensureView()
        handler.post(ticker)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureView()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applySettings()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        if (IslandBus.sink === this) IslandBus.sink = null
        try { view?.let { wm.removeView(it) } } catch (_: Throwable) {}
        view = null
        instance = null
        super.onDestroy()
    }

    // ───────── окно ─────────

    fun ensureView() {
        if (view != null) return
        if (!Settings.canDrawOverlays(this)) return
        val v = IslandView(this, this)
        lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(v, lp)
            view = v
            applySettings()
        } catch (_: Throwable) {
            view = null
        }
    }

    private fun applySettings() {
        val v = view ?: return
        val d = resources.displayMetrics.density
        lp.x = (Prefs.int(this, Prefs.OFF_X, 0) * d).toInt()
        lp.y = (Prefs.int(this, Prefs.OFF_Y, 6) * d).toInt()
        v.configure(Prefs.int(this, Prefs.SCALE, 100) / 100f, Prefs.bool(this, Prefs.SHOW_IDLE, true))
        pushData()
        try { wm.updateViewLayout(v, lp) } catch (_: Throwable) {}
    }

    private fun pushData() {
        val v = view ?: return
        v.setMusic(if (Prefs.bool(this, Prefs.MUSIC, true)) IslandBus.music else null)
        v.setTaxi(IslandBus.taxi)
    }

    /** Вызывается из MainActivity, когда стартовал таймер. */
    fun refresh() {
        view?.showTimer()
    }

    // ───────── IslandView.Host ─────────

    override fun resizeWindow(w: Int, h: Int) {
        val v = view ?: return
        lp.width = w
        lp.height = h
        try { wm.updateViewLayout(v, lp) } catch (_: Throwable) {}
    }

    override fun media(action: Int) {
        val tc = IslandBus.controller?.transportControls ?: return
        when (action) {
            0 -> tc.skipToPrevious()
            1 -> if (IslandBus.music?.playing == true) tc.pause() else tc.play()
            2 -> tc.skipToNext()
        }
    }

    override fun timerFinished() {
        try {
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vib.vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Throwable) {}
    }

    // ───────── IslandBus.Sink ─────────

    override fun onChanged() = pushData()

    override fun onNotif(n: NotifState) {
        if (Prefs.bool(this, Prefs.NOTIF, true)) view?.postNotif(n)
    }

    // ───────── foreground ─────────

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "AlteIsland", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("AlteIsland работает")
            .setContentText("Остров активен. Нажмите, чтобы открыть настройки")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID, n)
        }
    }
}
