package com.islandx.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Сам "остров": чёрная капсула, которая плавно (с пружинным овершутом) меняет размер
 * между состояниями IDLE (пустая) → COMPACT (иконка + значение) → EXPANDED (полная карточка).
 */
class IslandView(ctx: Context, private val host: Host) : FrameLayout(ctx) {

    interface Host {
        fun resizeWindow(w: Int, h: Int)
        fun media(action: Int) // 0 = назад, 1 = пауза/играть, 2 = вперёд
        fun timerFinished()
    }

    enum class Kind { TAXI, TIMER, MUSIC, NOTIF }
    private enum class Mode { IDLE, COMPACT, EXPANDED }

    companion object {
        const val IDLE_W = 124f
        const val IDLE_H = 34f
        const val COMP_W = 210f
        const val EXP_W = 360f
        private val WHITE = Color.WHITE
        private val GRAY = Color.parseColor("#9A9AA0")
        private val ORANGE = Color.parseColor("#FF9F0A")
        private val YELLOW = Color.parseColor("#FFD60A")
    }

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val d = resources.displayMetrics.density
    private fun dp(v: Float): Float = v * d
    private fun dpi(v: Float): Int = (v * d).toInt()

    private val island = FrameLayout(ctx)
    private val content = FrameLayout(ctx)
    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }

    private var scale = 1f
    private var idleVisible = true

    private var music: MusicState? = null
    private var taxi: TaxiState? = null
    private var notif: NotifState? = null

    private var kind: Kind? = null
    private var renderedKind: Kind? = null
    private var mode = Mode.IDLE
    private var wantExpanded = false

    private var curW = dp(IDLE_W)
    private var curH = dp(IDLE_H)
    private var curR = dp(IDLE_H) / 2f
    private var anim: ValueAnimator? = null
    private var autoDone: (() -> Unit)? = null

    // ссылки на живые элементы текущей карточки
    private var tvTitle: TextView? = null
    private var tvSub: TextView? = null
    private var tvTime: TextView? = null
    private var tvPos: TextView? = null
    private var tvDur: TextView? = null
    private var tvEta: TextView? = null
    private var btnToggle: TextView? = null
    private var btnAdd: TextView? = null
    private var eq: EqView? = null
    private var bar: BarView? = null
    private var playIcon: IconView? = null
    private var route: RouteView? = null

    private val autoCollapse = Runnable {
        wantExpanded = false
        val dn = autoDone
        autoDone = null
        dn?.invoke()
        update()
    }

    private var downX = 0f
    private var downY = 0f
    private var longFired = false
    private val longRun = Runnable {
        longFired = true
        cycle(1)
    }

    init {
        clipChildren = false
        clipToPadding = false
        island.background = bg
        island.clipToOutline = true
        island.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, bg.cornerRadius)
            }
        }
        island.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(
            island,
            FrameLayout.LayoutParams(dpi(IDLE_W), dpi(IDLE_H), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        )
        island.setOnTouchListener { _, e -> onIslandTouch(e) }
        applySize(curW, curH, curR)
    }

    // ───────────────────────── публичное API ─────────────────────────

    fun configure(userScale: Float, showIdle: Boolean) {
        val fit = resources.displayMetrics.widthPixels * 0.96f / dp(EXP_W + 30f)
        scale = min(userScale, fit)
        idleVisible = showIdle
        island.scaleX = scale
        island.scaleY = scale
        update(animated = false, force = true)
    }

    fun setMusic(m: MusicState?) {
        val old = music
        music = m
        if (m != null && m.playing && (old == null || old.title != m.title)) {
            if (kind == null || kind == Kind.MUSIC) {
                kind = Kind.MUSIC
                autoExpand(3000)
                return
            }
        }
        update()
    }

    fun setTaxi(t: TaxiState?) {
        val old = taxi
        taxi = t
        if (t != null && old == null) {
            kind = Kind.TAXI
            autoExpand(4000)
        } else {
            update()
        }
    }

    fun postNotif(n: NotifState) {
        notif = n
        kind = Kind.NOTIF
        autoExpand(5000) { notif = null }
    }

    fun showTimer() {
        kind = Kind.TIMER
        autoExpand(2500)
    }

    fun tick() {
        if (TimerState.running && TimerState.remaining() <= 0L) {
            TimerState.finish()
            host.timerFinished()
            kind = Kind.TIMER
            autoExpand(6000) { TimerState.reset() }
            return
        }
        update()
    }

    fun autoExpand(ms: Long, done: (() -> Unit)? = null) {
        island.removeCallbacks(autoCollapse)
        autoDone = done
        wantExpanded = true
        update()
        island.postDelayed(autoCollapse, ms)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        island.removeCallbacks(autoCollapse)
        island.removeCallbacks(longRun)
        anim?.cancel()
    }

    // ───────────────────────── логика состояний ─────────────────────────

    private fun kinds(): List<Kind> {
        val l = ArrayList<Kind>()
        if (taxi != null) l.add(Kind.TAXI)
        if (TimerState.active()) l.add(Kind.TIMER)
        val m = music
        if (m != null && (m.playing || SystemClock.elapsedRealtime() - m.updatedAt < 30000L)) l.add(Kind.MUSIC)
        if (notif != null) l.add(Kind.NOTIF)
        return l
    }

    private fun update(animated: Boolean = true, force: Boolean = false) {
        val ks = kinds()
        val cur = kind
        if (cur == null || !ks.contains(cur)) kind = ks.firstOrNull()
        val k = kind
        if (k == null) wantExpanded = false
        val newMode = when {
            k == null -> Mode.IDLE
            wantExpanded -> Mode.EXPANDED
            else -> Mode.COMPACT
        }
        val changed = force || newMode != mode || k != renderedKind
        if (!changed) {
            refreshDynamic()
            return
        }
        mode = newMode
        renderedKind = k
        val size = targetSize()
        val r = if (mode == Mode.EXPANDED) dp(34f) else size.second / 2f
        renderContent()
        animateTo(size.first, size.second, r, animated && !force)
    }

    private fun expH(k: Kind?): Float = when (k) {
        Kind.MUSIC -> 176f
        Kind.TIMER -> 150f
        Kind.TAXI -> 196f
        Kind.NOTIF -> 118f
        null -> 150f
    }

    private fun targetSize(): Pair<Float, Float> = when (mode) {
        Mode.IDLE -> Pair(dp(IDLE_W), dp(IDLE_H))
        Mode.COMPACT -> Pair(dp(COMP_W), dp(IDLE_H + 2f))
        Mode.EXPANDED -> Pair(dp(EXP_W), dp(expH(kind)))
    }

    private fun animateTo(w: Float, h: Float, r: Float, animated: Boolean) {
        val old = anim
        anim = null
        old?.cancel()
        island.visibility = View.VISIBLE
        val fw = curW
        val fh = curH
        val fr = curR
        // окно на время анимации делаем с запасом под овершут
        val needW = max(fw, w) + dp(40f)
        val needH = max(fh, h) + dp(40f)
        host.resizeWindow(ceil(needW * scale).toInt(), ceil(needH * scale).toInt())
        if (!animated) {
            applySize(w, h, r)
            finishResize(w, h)
            return
        }
        val expanding = w * h > fw * fh
        val va = ValueAnimator.ofFloat(0f, 1f)
        va.duration = if (expanding) 520L else 380L
        va.interpolator = OvershootInterpolator(if (expanding) 1.25f else 0.7f)
        va.addUpdateListener {
            val t = it.animatedValue as Float
            applySize(fw + (w - fw) * t, fh + (h - fh) * t, fr + (r - fr) * t)
        }
        va.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(a: Animator) {
                if (anim === va) {
                    applySize(w, h, r)
                    finishResize(w, h)
                }
            }
        })
        anim = va
        va.start()
    }

    private fun applySize(w: Float, h: Float, r: Float) {
        curW = w
        curH = h
        curR = r
        val lp = island.layoutParams as FrameLayout.LayoutParams
        lp.width = max(w, dp(30f)).toInt()
        lp.height = max(h, dp(20f)).toInt()
        bg.cornerRadius = min(r, lp.height / 2f)
        island.layoutParams = lp
        island.pivotX = lp.width / 2f
        island.pivotY = 0f
        island.invalidateOutline()
    }

    private fun finishResize(w: Float, h: Float) {
        if (mode == Mode.IDLE && !idleVisible) {
            island.visibility = View.INVISIBLE
            host.resizeWindow(1, 1)
            return
        }
        island.visibility = View.VISIBLE
        host.resizeWindow(ceil((w + dp(8f)) * scale).toInt(), ceil((h + dp(8f)) * scale).toInt())
    }

    // ───────────────────────── жесты ─────────────────────────

    private fun onIslandTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                longFired = false
                island.postDelayed(longRun, 500)
            }
            MotionEvent.ACTION_MOVE -> {
                if (hypot(e.rawX - downX, e.rawY - downY) > dp(10f)) island.removeCallbacks(longRun)
            }
            MotionEvent.ACTION_UP -> {
                island.removeCallbacks(longRun)
                if (!longFired) {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    val th = dp(36f) * scale
                    when {
                        abs(dx) > th && abs(dx) > abs(dy) -> cycle(if (dx < 0) 1 else -1)
                        dy > th && abs(dy) > abs(dx) -> setExpanded(true)
                        dy < -th && abs(dy) > abs(dx) -> setExpanded(false)
                        abs(dx) < dp(10f) && abs(dy) < dp(10f) -> onTap()
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> island.removeCallbacks(longRun)
        }
        return true
    }

    private fun onTap() {
        if (kind == null) {
            island.animate().scaleX(scale * 1.08f).scaleY(scale * 1.08f).setDuration(120).withEndAction {
                island.animate().scaleX(scale).scaleY(scale).setDuration(160).start()
            }.start()
            return
        }
        setExpanded(!wantExpanded)
    }

    private fun setExpanded(b: Boolean) {
        if (kind == null) return
        island.removeCallbacks(autoCollapse)
        val dn = autoDone
        autoDone = null
        wantExpanded = b
        if (!b) dn?.invoke()
        update()
    }

    private fun cycle(dir: Int) {
        val ks = kinds()
        if (ks.size < 2) return
        val i = max(0, ks.indexOf(kind))
        kind = ks[(i + dir + ks.size) % ks.size]
        update()
    }

    // ───────────────────────── отрисовка контента ─────────────────────────

    private fun renderContent() {
        content.removeAllViews()
        tvTitle = null; tvSub = null; tvTime = null; tvPos = null; tvDur = null; tvEta = null
        btnToggle = null; btnAdd = null; eq = null; bar = null; playIcon = null; route = null

        val v: View? = when (mode) {
            Mode.IDLE -> null
            Mode.COMPACT -> buildCompact()
            Mode.EXPANDED -> when (kind) {
                Kind.MUSIC -> buildMusic()
                Kind.TIMER -> buildTimer()
                Kind.TAXI -> buildTaxi()
                Kind.NOTIF -> buildNotif()
                null -> null
            }
        }
        if (v == null) return
        val w = if (mode == Mode.EXPANDED) dpi(EXP_W) else dpi(COMP_W)
        val h = targetSize().second.toInt()
        v.alpha = 0f
        content.addView(v, FrameLayout.LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        v.animate().alpha(1f).setStartDelay(if (mode == Mode.EXPANDED) 130L else 80L).setDuration(220).start()
        refreshDynamic()
    }

    private fun refreshDynamic() {
        when (kind) {
            Kind.MUSIC -> {
                val m = music ?: return
                tvTitle?.text = m.title
                tvSub?.text = m.artist
                eq?.active = m.playing
                playIcon?.set(if (m.playing) IconView.PAUSE else IconView.PLAY)
                val pos = musicPos()
                tvPos?.text = fmt(pos)
                tvDur?.text = fmt(m.durMs)
                bar?.value = if (m.durMs > 0) pos.toFloat() / m.durMs else 0f
            }
            Kind.TIMER -> {
                tvTime?.text = timerText()
                btnToggle?.text = if (TimerState.running) "Пауза" else "Продолжить"
                val vis = if (TimerState.finished) View.GONE else View.VISIBLE
                btnToggle?.visibility = vis
                btnAdd?.visibility = vis
            }
            Kind.TAXI -> {
                val t = taxi ?: return
                tvEta?.text = etaText()
                tvTitle?.text = t.title
                tvSub?.text = t.text
                route?.progress = taxiProgress()
            }
            Kind.NOTIF -> {}
            null -> {}
        }
    }

    // ───────────────────────── билдеры карточек ─────────────────────────

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(context)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_DIP, size)
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        t.includeFontPadding = false
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        return t
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(context)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        return r
    }

    private fun col(): LinearLayout {
        val c = LinearLayout(context)
        c.orientation = LinearLayout.VERTICAL
        return c
    }

    private fun lpw(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun roundOutline(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, r)
        }
    }

    private fun artView(sizeDp: Float, radiusDp: Float, bmp: Bitmap?, placeholder: String = "\u266A"): View {
        if (bmp != null) {
            val iv = ImageView(context)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(bmp)
            iv.clipToOutline = true
            iv.outlineProvider = roundOutline(dp(radiusDp))
            return iv
        }
        val t = TextView(context)
        t.text = placeholder
        t.gravity = Gravity.CENTER
        t.setTextColor(WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_DIP, sizeDp * 0.5f)
        val g = GradientDrawable()
        g.setColor(Color.parseColor("#3A3A3C"))
        g.cornerRadius = dp(radiusDp)
        t.background = g
        return t
    }

    private fun pill(label: String, fg: Int, bgc: Int, onClick: () -> Unit): TextView {
        val t = TextView(context)
        t.text = label
        t.setTextColor(fg)
        t.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14f)
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setPadding(dpi(16f), 0, dpi(16f), 0)
        val g = GradientDrawable()
        g.setColor(bgc)
        g.cornerRadius = dp(20f)
        t.background = g
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildCompact(): View {
        val r = row()
        r.setPadding(dpi(12f), 0, dpi(14f), 0)
        fun gap() = r.addView(View(context), lpw(0, 1, 1f))
        when (kind) {
            Kind.MUSIC -> {
                r.addView(artView(22f, 6f, music?.art), lpw(dpi(22f), dpi(22f)))
                gap()
                val e = EqView(context)
                e.active = music?.playing == true
                eq = e
                r.addView(e, lpw(dpi(18f), dpi(16f)))
            }
            Kind.TIMER -> {
                r.addView(tv("\u23F1", 15f, ORANGE))
                gap()
                val t = tv(timerText(), 14f, ORANGE, true)
                tvTime = t
                r.addView(t)
            }
            Kind.TAXI -> {
                r.addView(tv("\uD83D\uDE95", 15f, WHITE))
                gap()
                val t = tv(etaText(), 14f, YELLOW, true)
                tvEta = t
                r.addView(t)
            }
            Kind.NOTIF -> {
                val n = notif
                r.addView(artView(22f, 6f, n?.icon, "\uD83D\uDD14"), lpw(dpi(22f), dpi(22f)))
                gap()
                val t = tv(n?.title ?: "", 12f, WHITE)
                t.maxWidth = dpi(80f)
                r.addView(t)
            }
            null -> {}
        }
        return r
    }

    private fun buildMusic(): View {
        val m = music
        val c = col()
        c.setPadding(dpi(18f), dpi(18f), dpi(18f), dpi(12f))
        val r1 = row()
        r1.addView(artView(56f, 10f, m?.art), lpw(dpi(56f), dpi(56f)))
        val tc = col()
        tc.setPadding(dpi(12f), 0, dpi(8f), 0)
        val title = tv(m?.title ?: "", 16f, WHITE, true)
        val sub = tv(m?.artist ?: "", 14f, GRAY)
        tvTitle = title
        tvSub = sub
        tc.addView(title)
        tc.addView(sub, lpw(MATCH, WRAP).also { it.topMargin = dpi(2f) })
        r1.addView(tc, lpw(0, WRAP, 1f))
        val e = EqView(context)
        e.active = m?.playing == true
        eq = e
        r1.addView(e, lpw(dpi(22f), dpi(20f)))
        c.addView(r1, lpw(MATCH, WRAP))

        val r2 = row()
        val pos = tv("0:00", 11f, GRAY)
        val dur = tv("0:00", 11f, GRAY)
        val b = BarView(context, "#FFFFFF")
        tvPos = pos
        tvDur = dur
        bar = b
        r2.addView(pos)
        val bl = lpw(0, dpi(4f), 1f)
        bl.setMargins(dpi(8f), 0, dpi(8f), 0)
        r2.addView(b, bl)
        r2.addView(dur)
        c.addView(r2, lpw(MATCH, WRAP).also { it.topMargin = dpi(12f) })

        val r3 = row()
        r3.gravity = Gravity.CENTER
        val prev = IconView(context, IconView.PREV)
        prev.setOnClickListener { host.media(0) }
        val play = IconView(context, if (m?.playing == true) IconView.PAUSE else IconView.PLAY)
        play.setOnClickListener { host.media(1) }
        playIcon = play
        val next = IconView(context, IconView.NEXT)
        next.setOnClickListener { host.media(2) }
        r3.addView(prev, lpw(dpi(52f), dpi(44f)))
        r3.addView(play, lpw(dpi(60f), dpi(48f)))
        r3.addView(next, lpw(dpi(52f), dpi(44f)))
        c.addView(r3, lpw(MATCH, WRAP).also { it.topMargin = dpi(6f) })
        return c
    }

    private fun buildTimer(): View {
        val c = col()
        c.setPadding(dpi(20f), dpi(16f), dpi(20f), dpi(14f))
        c.addView(tv("\u23F1  Таймер", 13f, ORANGE, true))
        val t = tv(timerText(), 46f, WHITE)
        t.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        tvTime = t
        c.addView(t, lpw(MATCH, WRAP).also { it.topMargin = dpi(4f) })

        val r = row()
        val toggle = pill("Пауза", Color.BLACK, ORANGE) { TimerState.toggle(); update() }
        val add = pill("+1 мин", WHITE, Color.parseColor("#3A3A3C")) { TimerState.add(60_000L); update() }
        val reset = pill("Сброс", WHITE, Color.parseColor("#3A3A3C")) {
            TimerState.reset()
            island.removeCallbacks(autoCollapse)
            autoDone = null
            update()
        }
        btnToggle = toggle
        btnAdd = add
        r.addView(toggle, lpw(WRAP, dpi(38f)).also { it.rightMargin = dpi(8f) })
        r.addView(add, lpw(WRAP, dpi(38f)).also { it.rightMargin = dpi(8f) })
        r.addView(reset, lpw(WRAP, dpi(38f)))
        c.addView(r, lpw(MATCH, WRAP).also { it.topMargin = dpi(10f) })
        return c
    }

    private fun buildTaxi(): View {
        val t = taxi
        val c = col()
        c.setPadding(dpi(20f), dpi(16f), dpi(20f), dpi(14f))
        val r1 = row()
        r1.addView(tv("\uD83D\uDE95  " + (t?.app ?: "Такси"), 13f, YELLOW, true), lpw(0, WRAP, 1f))
        val eta = tv(etaText(), 22f, WHITE, true)
        tvEta = eta
        r1.addView(eta)
        c.addView(r1, lpw(MATCH, WRAP))
        val title = tv(t?.title ?: "", 16f, WHITE, true)
        tvTitle = title
        c.addView(title, lpw(MATCH, WRAP).also { it.topMargin = dpi(6f) })
        val sub = tv(t?.text ?: "", 13f, GRAY)
        sub.maxLines = 2
        tvSub = sub
        c.addView(sub, lpw(MATCH, WRAP).also { it.topMargin = dpi(2f) })
        val rv = RouteView(context)
        rv.progress = taxiProgress()
        route = rv
        c.addView(rv, lpw(MATCH, dpi(40f)).also { it.topMargin = dpi(8f) })
        val r3 = row()
        val from = tv(if (t?.from.isNullOrBlank()) "Подача" else t!!.from, 12f, GRAY)
        val to = tv(if (t?.to.isNullOrBlank()) "Назначение" else t!!.to, 12f, WHITE)
        r3.addView(from, lpw(0, WRAP, 1f))
        to.gravity = Gravity.END
        r3.addView(to, lpw(0, WRAP, 1f))
        c.addView(r3, lpw(MATCH, WRAP))
        return c
    }

    private fun buildNotif(): View {
        val n = notif
        val r = row()
        r.setPadding(dpi(18f), dpi(14f), dpi(18f), dpi(14f))
        r.addView(artView(44f, 10f, n?.icon, "\uD83D\uDD14"), lpw(dpi(44f), dpi(44f)))
        val c = col()
        c.setPadding(dpi(12f), 0, 0, 0)
        c.addView(tv(n?.app ?: "", 12f, GRAY))
        c.addView(tv(n?.title ?: "", 15f, WHITE, true), lpw(MATCH, WRAP).also { it.topMargin = dpi(2f) })
        val body = tv(n?.text ?: "", 13f, Color.parseColor("#D0D0D5"))
        body.maxLines = 2
        c.addView(body, lpw(MATCH, WRAP).also { it.topMargin = dpi(2f) })
        r.addView(c, lpw(0, WRAP, 1f))
        r.setOnClickListener {
            try { n?.intent?.send() } catch (_: Exception) {}
            island.removeCallbacks(autoCollapse)
            autoDone = null
            notif = null
            wantExpanded = false
            update()
        }
        return r
    }

    // ───────────────────────── утилиты ─────────────────────────

    private fun fmt(ms: Long): String {
        val s = max(0L, ceil(ms / 1000.0).toLong())
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    private fun timerText(): String =
        if (TimerState.finished) "Готово!" else fmt(TimerState.remaining())

    private fun etaText(): String {
        val e = taxi?.etaMin
        return when {
            e == null -> "в пути"
            e <= 0 -> "На месте"
            else -> "$e мин"
        }
    }

    private fun taxiProgress(): Float {
        val t = taxi ?: return 0f
        val e = t.etaMin ?: return 0.3f
        val s = t.startEta ?: return 0.3f
        if (s <= 0) return 0.5f
        return (1f - e.toFloat() / s).coerceIn(0.03f, 1f)
    }

    private fun musicPos(): Long {
        val m = music ?: return 0L
        if (!m.playing) return m.posMs
        val el = SystemClock.elapsedRealtime() - m.updatedAt
        val p = m.posMs + (el * m.speed).toLong()
        return if (m.durMs > 0) min(p, m.durMs) else p
    }
}
