package com.islandx.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

class MainActivity : Activity() {

    private val refreshers = ArrayList<() -> Unit>()
    private val simHandler = Handler(Looper.getMainLooper())
    private var sim: Runnable? = null

    private val GRAY = Color.parseColor("#9A9AA0")
    private val GREEN = Color.parseColor("#30D158")
    private val RED = Color.parseColor("#FF453A")

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(32), dp(20), dp(48))
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("AlteIsland", 30f, Color.WHITE, true))
        root.addView(label("Динамический остров для Android", 14f, GRAY))

        // ── разрешения ──
        root.addView(section("1. Разрешения"))
        perm(root, "Поверх других окон", "Нужно, чтобы остров рисовался над приложениями.",
            { Settings.canDrawOverlays(this) }) {
            open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        perm(root, "Доступ к уведомлениям", "Нужно для уведомлений, музыки и такси. " +
            "Если пункт серый: Настройки → Приложения → AlteIsland → ⋮ → «Разрешить ограниченные настройки».",
            { NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName) }) {
            open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        perm(root, "Показ уведомлений (Android 13+)", "Для значка «Остров работает».",
            {
                Build.VERSION.SDK_INT < 33 ||
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            }) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        perm(root, "Работа в фоне", "Отключите оптимизацию батареи, чтобы система не убивала остров.",
            { getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName) }) {
            open(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        root.addView(button("Автозапуск / настройки приложения (Xiaomi, Huawei, Samsung…)") {
            open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        // ── запуск ──
        root.addView(section("2. Запуск"))
        val startStop = LinearLayout(this)
        startStop.orientation = LinearLayout.HORIZONTAL
        startStop.addView(button("Запустить") { startIsland() }, LinearLayout.LayoutParams(0, -2, 1f))
        startStop.addView(button("Остановить") {
            Prefs.putBool(this, Prefs.ENABLED, false)
            stopService(Intent(this, OverlayService::class.java))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(startStop)

        // ── внешний вид ──
        root.addView(section("3. Размер и положение (меняется сразу)"))
        root.addView(slider("Размер", Prefs.SCALE, 50, 140, 100, "%"))
        root.addView(slider("Смещение по горизонтали", Prefs.OFF_X, -160, 160, 0, " dp"))
        root.addView(slider("Отступ сверху", Prefs.OFF_Y, 0, 220, 6, " dp"))
        root.addView(toggle("Показывать пустой остров в покое", Prefs.SHOW_IDLE, true))
        root.addView(toggle("Уведомления в острове", Prefs.NOTIF, true))
        root.addView(toggle("Музыкальный плеер", Prefs.MUSIC, true))

        // ── таймер ──
        root.addView(section("4. Таймер"))
        val presets = LinearLayout(this)
        presets.orientation = LinearLayout.HORIZONTAL
        for (m in intArrayOf(1, 5, 10, 15)) {
            presets.addView(button("$m мин") { startTimer(m) }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(presets)
        val custom = LinearLayout(this)
        custom.orientation = LinearLayout.HORIZONTAL
        val et = EditText(this)
        et.hint = "минут"
        et.setHintTextColor(GRAY)
        et.setTextColor(Color.WHITE)
        et.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        custom.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        custom.addView(button("Старт") {
            val m = et.text.toString().toIntOrNull()
            if (m != null && m in 1..600) startTimer(m) else toast("Введите от 1 до 600 минут")
        }, LinearLayout.LayoutParams(-2, -2))
        root.addView(custom)

        // ── тест ──
        root.addView(section("5. Проверка"))
        root.addView(button("Тестовое уведомление") {
            ensureService()
            IslandBus.postNotif(NotifState("Сообщения", "Анна", "Привет! Ты скоро будешь?", null, null))
        })
        root.addView(button("Демо: поездка на такси") { ensureService(); demoTaxi() })
        root.addView(button("Убрать такси") {
            sim?.let { simHandler.removeCallbacks(it) }
            IslandBus.setTaxi(null)
        })
        root.addView(label(
            "Музыка подхватывается автоматически: включите трек в любом плеере (Spotify, YouTube Music, VK…). " +
                "Жесты: тап — развернуть/свернуть, свайп влево/вправо — переключить активность, долгое нажатие — следующая.",
            12f, GRAY))
    }

    override fun onResume() {
        super.onResume()
        refreshers.forEach { it() }
        if (Prefs.bool(this, Prefs.ENABLED, true) && Settings.canDrawOverlays(this)) {
            val s = OverlayService.instance
            if (s == null) OverlayService.start(this) else s.ensureView()
        }
    }

    // ───────── действия ─────────

    private fun startIsland() {
        Prefs.putBool(this, Prefs.ENABLED, true)
        if (!Settings.canDrawOverlays(this)) {
            toast("Сначала выдайте разрешение «Поверх других окон»")
            open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        OverlayService.start(this)
    }

    private fun ensureService() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Сначала выдайте разрешение «Поверх других окон»")
            return
        }
        if (OverlayService.instance == null) OverlayService.start(this)
    }

    private fun startTimer(min: Int) {
        ensureService()
        TimerState.start(min * 60_000L)
        OverlayService.instance?.refresh()
    }

    private fun demoTaxi() {
        sim?.let { simHandler.removeCallbacks(it) }
        var eta = 8
        val r = object : Runnable {
            override fun run() {
                if (eta < 0) {
                    IslandBus.setTaxi(null)
                    return
                }
                IslandBus.setTaxi(
                    TaxiState(
                        "Такси", if (eta > 0) "Водитель в пути" else "Водитель прибыл",
                        "Toyota Camry · А 777 АА 77", eta, 8, "Тверская, 7", "Аэропорт Шереметьево"
                    )
                )
                eta--
                simHandler.postDelayed(this, 2500)
            }
        }
        sim = r
        simHandler.post(r)
    }

    private fun open(i: Intent) {
        try { startActivity(i) } catch (_: Throwable) { toast("Не удалось открыть настройки") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ───────── UI-хелперы ─────────

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(0, dp(4), 0, dp(4))
        return v
    }

    private fun section(t: String): TextView {
        val v = label(t, 18f, Color.WHITE, true)
        v.setPadding(0, dp(26), 0, dp(6))
        return v
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun perm(root: LinearLayout, title: String, hint: String, ok: () -> Boolean, action: () -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14), dp(10), dp(14), dp(10))
        val g = GradientDrawable()
        g.setColor(Color.parseColor("#1C1C1E"))
        g.cornerRadius = dp(14).toFloat()
        box.background = g
        val st = label("", 13f, GRAY, true)
        val b = button("Открыть настройки") { action() }
        box.addView(label(title, 16f, Color.WHITE, true))
        box.addView(label(hint, 12f, GRAY))
        box.addView(st)
        box.addView(b)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(8)
        root.addView(box, lp)
        refreshers.add {
            val granted = ok()
            st.text = if (granted) "✅ Выдано" else "❌ Не выдано"
            st.setTextColor(if (granted) GREEN else RED)
            b.visibility = if (granted) View.GONE else View.VISIBLE
        }
    }

    private fun slider(title: String, key: String, minV: Int, maxV: Int, def: Int, unit: String): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val cur = Prefs.int(this, key, def)
        val tv = label("$title: $cur$unit", 14f, Color.WHITE)
        val sb = SeekBar(this)
        sb.max = maxV - minV
        sb.progress = cur - minV
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + minV
                tv.text = "$title: $v$unit"
                if (fromUser) Prefs.putInt(this@MainActivity, key, v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun toggle(title: String, key: String, def: Boolean): View {
        val sw = Switch(this)
        sw.text = title
        sw.setTextColor(Color.WHITE)
        sw.isChecked = Prefs.bool(this, key, def)
        sw.setPadding(0, dp(10), 0, dp(10))
        sw.setOnCheckedChangeListener { _, c -> Prefs.putBool(this, key, c) }
        return sw
    }
}
