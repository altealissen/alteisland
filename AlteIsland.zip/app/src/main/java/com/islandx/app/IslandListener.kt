package com.islandx.app

import android.app.Notification
import android.content.ComponentName
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Читает уведомления и активные медиа-сессии (музыка) и передаёт их острову.
 * Требует выдачи "Доступ к уведомлениям" в настройках Android.
 */
class IslandListener : NotificationListenerService() {

    private val taxiPkgs = setOf(
        "ru.yandex.taxi",          // Яндекс Go
        "com.ubercab",             // Uber
        "ee.mtakso.client",        // Bolt
        "sinet.startup.inDriver",  // inDrive
        "ru.citymobil.passenger"   // Ситимобил
    )
    private val taxiWords = Regex("(водител|машин|такси|поездк|подач|driver|arriv|your ride|trip)", RegexOption.IGNORE_CASE)
    private val etaRegex = Regex("(\\d+)\\s*(мин|min)", RegexOption.IGNORE_CASE)

    private val lastSeen = HashMap<String, Int>()
    private var msm: MediaSessionManager? = null
    private var cn: ComponentName? = null
    private var controller: MediaController? = null

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list -> attach(list) }

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { pushMusic() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { pushMusic() }
        override fun onSessionDestroyed() {
            try { attach(msm?.getActiveSessions(cn)) } catch (_: Throwable) {}
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        try { OverlayService.start(this) } catch (_: Throwable) {}
        try {
            val m = getSystemService(MediaSessionManager::class.java)
            val c = ComponentName(this, IslandListener::class.java)
            msm = m
            cn = c
            m.addOnActiveSessionsChangedListener(sessionsListener, c)
            attach(m.getActiveSessions(c))
        } catch (_: Throwable) {}
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try { requestRebind(ComponentName(this, IslandListener::class.java)) } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Throwable) {}
        try { controller?.unregisterCallback(cb) } catch (_: Throwable) {}
        super.onDestroy()
    }

    // ───────── музыка ─────────

    private fun attach(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            try { controller?.unregisterCallback(cb) } catch (_: Throwable) {}
            controller = best
            try { best?.registerCallback(cb) } catch (_: Throwable) {}
        }
        pushMusic()
    }

    private fun pushMusic() {
        val c = controller
        if (c == null) {
            IslandBus.setMusic(null, null)
            return
        }
        val md = c.metadata
        val ps = c.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        if (title.isNullOrBlank()) {
            IslandBus.setMusic(null, c)
            return
        }
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: ""
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val st = ps?.state ?: PlaybackState.STATE_NONE
        val playing = st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING
        val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val pos = (ps?.position ?: 0L).coerceAtLeast(0L)
        val upd = ps?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime()
        val speed = ps?.playbackSpeed ?: 1f
        IslandBus.setMusic(
            MusicState(title, artist, art, playing, pos, dur.coerceAtLeast(0L), upd, speed),
            c
        )
    }

    // ───────── уведомления ─────────

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try { handle(sbn) } catch (_: Throwable) {}
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        lastSeen.remove(sbn.key)
        if (sbn.packageName in taxiPkgs && IslandBus.taxi != null && sbn.isOngoing) {
            IslandBus.setTaxi(null)
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return

        val h = (title + "|" + text).hashCode()
        if (lastSeen[sbn.key] == h) return
        lastSeen[sbn.key] = h

        val app = appName(sbn.packageName)

        if (sbn.packageName in taxiPkgs && (sbn.isOngoing || taxiWords.containsMatchIn("$title $text"))) {
            val eta = etaRegex.find("$title $text")?.groupValues?.get(1)?.toIntOrNull()
            val prevStart = IslandBus.taxi?.startEta
            val start = if (eta != null && (prevStart == null || eta > prevStart)) eta else prevStart
            IslandBus.setTaxi(TaxiState(app, title, text, eta, start, "", ""))
            return
        }

        if (n.category == Notification.CATEGORY_TRANSPORT || ex.containsKey(Notification.EXTRA_MEDIA_SESSION)) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (sbn.isOngoing) return

        var icon: Bitmap? = null
        try {
            val dr: Drawable? = n.getLargeIcon()?.loadDrawable(this)
                ?: packageManager.getApplicationIcon(sbn.packageName)
            if (dr != null) icon = toBitmap(dr)
        } catch (_: Throwable) {}

        IslandBus.postNotif(NotifState(app, title, text, icon, n.contentIntent))
    }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Throwable) {
        pkg
    }

    private fun toBitmap(d: Drawable, size: Int = 96): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return b
    }
}
