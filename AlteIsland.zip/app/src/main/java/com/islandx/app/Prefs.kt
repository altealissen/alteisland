package com.islandx.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val SCALE = "scale"          // 50..140 (%)
    const val OFF_X = "off_x"          // dp, -160..160
    const val OFF_Y = "off_y"          // dp, 0..220
    const val SHOW_IDLE = "show_idle"  // показывать пустой остров
    const val NOTIF = "notif"          // уведомления
    const val MUSIC = "music"          // плеер
    const val ENABLED = "enabled"      // автозапуск/работа

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("island", Context.MODE_PRIVATE)
    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
}
