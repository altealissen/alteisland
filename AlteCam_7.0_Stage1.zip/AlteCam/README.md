# Alte Cam 7.0-alpha — Stage 1 + core of Stage 2/5

Own computational-photography engine for Camera2 devices with `RAW_SENSOR` (target: Pixel 8).
**This is our own implementation of published ideas (HDR+ burst photography, pyramid block matching).
It is not Google's HDR+, Night Sight or Super Res Zoom.**

## What actually works (unit-tested on the JVM, synthetic data)
| Component | File | Status |
|---|---|---|
| Hierarchical tile alignment (4-level pyramid, ±sub-pixel, local per-tile vectors) | `engine/FrameAlignmentEngine.kt` | tested |
| Reference selection (sharpest), blur rejection, failed-alignment rejection | `engine/RawFusionEngine.kt` | tested |
| Bayer-domain robust merge with Camera2 noise model (`SENSOR_NOISE_PROFILE`), ghost rejection, exposure normalisation, saturation masking | `engine/RawFusionEngine.kt` | tested |
| Demosaic (Malvar-He-Cutler, all 4 CFA layouts) | `engine/DemosaicEngine.kt` | tested |
| WB + colour matrix, local shadow lift (bilateral base), tone curve, sRGB | `engine/RawDeveloper.kt` | tested (behavioural) |
| 16-bit RGB TIFF writer | `engine/TiffWriter.kt` | tested |
| Burst size limiter by memory / thermal state | `engine/BurstPlanner.kt` | tested |
| Camera2 burst, timestamp matching of Image↔Result, DNG originals, background processing, cancel, progress | `RawCaptureActivity.kt` | **not compiled, not run** |
| Real device capability probe, RawMeta from Camera2 | `CameraCapabilities.kt` | **not compiled, not run** |

Bugs fixed vs 6.0: the PGM header was written with a literal `\n` (corrupt file); fusion ran on the camera thread;
integer shifts could break Bayer parity; sequential single-shot "burst" (long inter-frame gaps); no permission request in the RAW screen; no lifecycle close; `Image` leak paths.
The PGM output was replaced by a developed JPEG and optional 16-bit TIFF. Originals stay as DNG in `Pictures/Alte Cam/RAW Burst`.

## Not implemented yet (do not assume they exist)
Night modes, Super Res Zoom, AI/ML models, Portrait/bokeh, Pro controls, Video engine, new UI/Gallery/Editor,
lens-shading correction in our own developer (DNGs still carry it), denoise/sharpen post-filters, C++/NDK/NEON/Vulkan,
DNG output of the *fused* image (fused result is JPEG/TIFF), rotation-aware alignment (only per-tile translation).
Old `MainActivity` modes (HDR/Night/Boost) are still the 8-bit CameraX JPEG pipeline from 6.0.

## Build / test
CI: `.github/workflows/build.yml` runs `gradle :app:testDebugUnitTest` then `:app:assembleDebug` and uploads the APK + test report.
minSdk raised to 29 (MediaStore RELATIVE_PATH; Pixel 8 ships Android 14+).
See `TEST_RESULTS.txt` for the measured numbers. Image quality on real Pixel 8 RAW has NOT been evaluated.
