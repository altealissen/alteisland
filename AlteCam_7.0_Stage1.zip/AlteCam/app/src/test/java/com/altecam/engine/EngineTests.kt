package com.altecam.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import java.util.concurrent.CancellationException
import kotlin.math.abs

private const val W = 640
private const val H = 480

private fun burst(
    shifts: List<Pair<Double, Double>>, seed: Long, noise: Boolean = true,
    box: Boolean = false, blurIdx: Int = -1, blur: Int = 0, gains: List<Float>? = null,
    cfa: CfaPattern = CfaPattern.RGGB, brightness: Double = 1.0
): Pair<List<RawFrame>, List<FloatArray>> {
    val rng = Random(seed)
    val frames = ArrayList<RawFrame>(); val cleans = ArrayList<FloatArray>()
    for ((i, s) in shifts.withIndex()) {
        val g = gains?.get(i) ?: 1f
        val clean = Synth.cleanMosaic(W, H, s.first, s.second, cfa, brightness, box, boxX = i * 25.0)
        val meta = Synth.meta(exposureNs = (10_000_000L * g).toLong(), cfa = cfa)
        frames.add(Synth.toRaw(clean, W, H, meta, rng, g, if (i == blurIdx) blur else 0))
        cleans.add(clean)
    }
    return Pair(frames, cleans)
}

private val HANDSHAKE = listOf(0.0 to 0.0, 3.4 to -2.2, -5.7 to 4.1, 7.3 to 1.6, -2.1 to -6.4)

class AlignmentTests {
    @Test fun recoversKnownGlobalShift() {
        // even/odd and sub-pixel shifts. Vector v satisfies alt(x+v)=ref(x); scene shifted by +s => v = -s/2 half-res px
        for ((sx, sy) in listOf(4.0 to 6.0, 5.0 to -3.0, 7.5 to 2.5)) {
            val (frames, _) = burst(listOf(0.0 to 0.0, sx to sy), 11, noise = true)
            val p0 = FrameAlignmentEngine.binHalf(frames[0], 1f); val p1 = FrameAlignmentEngine.binHalf(frames[1], 1f)
            val f = FrameAlignmentEngine.align(FrameAlignmentEngine.buildPyramid(p0, 16), FrameAlignmentEngine.buildPyramid(p1, 16), 16, true)
            val mid = (f.tilesY / 2) * f.tilesX + f.tilesX / 2
            assertEquals("vx for shift ($sx,$sy)", -sx / 2, f.vx[mid].toDouble(), 0.35)
            assertEquals("vy for shift ($sx,$sy)", -sy / 2, f.vy[mid].toDouble(), 0.35)
        }
    }

    @Test fun localMotionGivesDifferentVectorsInsideMovingRegion() {
        val (frames, _) = burst(listOf(0.0 to 0.0, 0.0 to 0.0), 5, box = true)
        // second frame has the box displaced by 25 raw px (boxX = i*25), background static
        val p0 = FrameAlignmentEngine.binHalf(frames[0], 1f); val p1 = FrameAlignmentEngine.binHalf(frames[1], 1f)
        val f = FrameAlignmentEngine.align(FrameAlignmentEngine.buildPyramid(p0, 16), FrameAlignmentEngine.buildPyramid(p1, 16), 16, true)
        var staticOk = 0; var staticN = 0
        for (j in 0 until f.tilesY) for (i in 0 until f.tilesX) if (i > 12 && j > 8) { staticN++; if (abs(f.vx[j * f.tilesX + i]) < 0.6f && abs(f.vy[j * f.tilesX + i]) < 0.6f) staticOk++ }
        assertTrue("static tiles keep ~zero vectors ($staticOk/$staticN)", staticOk >= staticN * 0.9)
    }

    @Test fun sharpnessDropsWithMotionBlur() {
        val (frames, _) = burst(listOf(0.0 to 0.0, 0.0 to 0.0), 3, blurIdx = 1, blur = 8)
        val a = FrameAlignmentEngine.sharpness(FrameAlignmentEngine.buildPyramid(FrameAlignmentEngine.binHalf(frames[0], 1f), 16)[2])
        val b = FrameAlignmentEngine.sharpness(FrameAlignmentEngine.buildPyramid(FrameAlignmentEngine.binHalf(frames[1], 1f), 16)[2])
        assertTrue("blurred sharpness $b < sharp $a", b < a * 0.7f)
    }
}

class RawFusionTests {
    @Test fun fusionBeatsSingleFrameAndLegacyMedian() {
        val (frames, cleans) = burst(HANDSHAKE, 42)
        val res = RawFusionEngine.fuse(frames)
        val clean = cleans[res.referenceIndex]
        val single = Synth.psnrRaw(frames[res.referenceIndex], clean)
        val fused = Synth.psnr(res.bayer, clean, W, H)
        val legacy = Synth.psnr(Synth.legacyMedian(frames.map { it.data }, W, H), clean, W, H)
        println("METRIC handheld: single=%.2f dB  legacy-median=%.2f dB  new-fusion=%.2f dB  used=%s discarded=%s ms=%d".format(single, legacy, fused, res.usedFrames, res.discarded, res.elapsedMs))
        assertTrue("fused $fused must exceed single $single by >= 3 dB", fused >= single + 3.0)
        assertTrue("fused $fused must exceed legacy $legacy", fused > legacy)
    }

    @Test fun worksWithoutNoiseProfileUsingEstimatedNoise() {
        val rng = Random(9)
        val frames = HANDSHAKE.map { (sx, sy) ->
            Synth.toRaw(Synth.cleanMosaic(W, H, sx, sy), W, H, Synth.meta(withNoiseProfile = false), rng)
        }
        val res = RawFusionEngine.fuse(frames)
        val clean = Synth.cleanMosaic(W, H, HANDSHAKE[res.referenceIndex].first, HANDSHAKE[res.referenceIndex].second)
        val single = Synth.psnrRaw(frames[res.referenceIndex], clean)
        val fused = Synth.psnr(res.bayer, clean, W, H)
        println("METRIC no-noise-profile: single=%.2f dB fused=%.2f dB".format(single, fused))
        assertTrue(fused >= single + 2.5)
    }

    @Test fun tripodBurstGainsAboutSqrtN() {
        val (frames, cleans) = burst(List(5) { 0.0 to 0.0 }, 77)
        val res = RawFusionEngine.fuse(frames)
        val single = Synth.psnrRaw(frames[res.referenceIndex], cleans[0]); val fused = Synth.psnr(res.bayer, cleans[0], W, H)
        println("METRIC tripod: single=%.2f dB fused=%.2f dB (theory ~ +7.0 dB for 5 frames)".format(single, fused))
        assertTrue(fused >= single + 5.0)
    }

    @Test fun movingObjectIsNotGhosted() {
        val (frames, cleans) = burst(List(5) { 0.0 to 0.0 }, 21, box = true)
        val res = RawFusionEngine.fuse(frames)
        val ri = res.referenceIndex
        val box = { a: FloatArray ->
            // box region of the reference frame (raw px): x in 200+25*ri..260+25*ri, y 120..180; test its trailing area
            var se = 0.0; var n = 0
            for (y in 125 until 175) for (x in (205 + 25 * ri) until (255 + 25 * ri)) { val d = (a[y * W + x] - cleans[ri][y * W + x]).toDouble(); se += d * d; n++ }
            se / n
        }
        val fusedErr = box(res.bayer)
        val naiveAvg = FloatArray(W * H) { i -> cleans.sumOf { it[i].toDouble() }.toFloat() / 5f }
        val naiveErr = box(naiveAvg)
        println("METRIC ghosting: MSE in moving box  fused=%.5f  plain-average=%.5f".format(fusedErr, naiveErr))
        assertTrue("fused ghost error $fusedErr must be far below plain average $naiveErr", fusedErr < naiveErr * 0.25)
    }

    @Test fun blurredFrameIsDiscarded() {
        val (frames, _) = burst(List(5) { 0.0 to 0.0 }, 33, blurIdx = 3, blur = 12)
        val res = RawFusionEngine.fuse(frames)
        assertTrue("blurred frame 3 discarded: ${res.discarded}", res.discarded.containsKey(3))
        assertTrue(res.referenceIndex != 3)
    }

    @Test fun exposureNormalisationKeepsBrightness() {
        // alternate frames are 2x exposure (and 2x signal); fused level must stay at reference level
        val gains = listOf(1f, 2f, 1f, 2f, 1f)
        val (frames, cleans) = burst(List(5) { 0.0 to 0.0 }, 8, gains = gains, brightness = 0.35)
        val res = RawFusionEngine.fuse(frames)
        var mean = 0.0; var meanRef = 0.0; var n = 0
        for (y in 60 until H - 60) for (x in 60 until W - 60) { mean += res.bayer[y * W + x]; meanRef += cleans[0][y * W + x]; n++ }
        assertEquals("fused mean equals reference-exposure mean", meanRef / n, mean / n, 0.01 * meanRef / n + 0.003)
    }

    @Test fun allFourCfaLayoutsWork() {
        for (cfa in CfaPattern.values()) {
            val (frames, cleans) = burst(HANDSHAKE.take(3), 4, cfa = cfa)
            val res = RawFusionEngine.fuse(frames)
            val fused = Synth.psnr(res.bayer, cleans[res.referenceIndex], W, H)
            val single = Synth.psnrRaw(frames[res.referenceIndex], cleans[res.referenceIndex])
            assertTrue("$cfa fused $fused vs single $single", fused > single + 1.5)
        }
    }

    @Test fun singleFrameIsPassedThrough() {
        val (frames, cleans) = burst(listOf(0.0 to 0.0), 1)
        val res = RawFusionEngine.fuse(frames)
        assertEquals(listOf(0), res.usedFrames)
        assertTrue(Synth.psnr(res.bayer, cleans[0], W, H) > 20)
    }

    @Test fun rejectsMismatchedInputs() {
        val (frames, _) = burst(listOf(0.0 to 0.0, 1.0 to 0.0), 2)
        val small = RawFrame(128, 128, ShortArray(128 * 128), frames[0].meta)
        try { RawFusionEngine.fuse(listOf(frames[0], small)); fail("expected failure") } catch (_: IllegalArgumentException) {}
        try { RawFusionEngine.fuse(emptyList()); fail("expected failure") } catch (_: IllegalArgumentException) {}
    }

    @Test fun cancellationStopsProcessing() {
        val (frames, _) = burst(HANDSHAKE, 6)
        val token = CancelToken(); token.cancel()
        try { RawFusionEngine.fuse(frames, cancel = token); fail("expected cancellation") } catch (_: CancellationException) {}
    }

    @Test fun reportsProgressForAligningAndMerging() {
        val (frames, _) = burst(HANDSHAKE.take(3), 12)
        val stages = LinkedHashSet<String>(); var last = 0f
        RawFusionEngine.fuse(frames, progress = { s, f -> stages.add(s); last = f })
        assertTrue(stages.containsAll(listOf("Aligning", "Merging")))
    }

    @Test fun allocationBudgetStaysBounded() {
        // fused output (4 B/px) + a few per-row buffers; must not allocate full-size scratch per alt frame
        val (frames, _) = burst(HANDSHAKE, 14)
        val mx = java.lang.management.ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean
        val before = mx.getThreadAllocatedBytes(Thread.currentThread().id)
        RawFusionEngine.fuse(frames, FusionOptions(threads = 1))
        val used = mx.getThreadAllocatedBytes(Thread.currentThread().id) - before
        val framePx = W.toLong() * H
        println("METRIC allocation: %.1f MB for %d frames of %d px (%.1f B/px/frame)".format(used / 1e6, frames.size, framePx, used.toDouble() / framePx / frames.size))
        assertTrue("allocated ${used / 1e6} MB", used < framePx * 4 * 8) // < 8 full float planes
    }
}

class DemosaicTests {
    @Test fun reconstructsSmoothSceneForEveryCfa() {
        val w = 256; val h = 192
        val rgb = Synth.rgbScene(w, h)
        for (cfa in CfaPattern.values()) {
            val mosaic = Synth.mosaicFromRgb(rgb, w, h, cfa)
            val row = FloatArray(3 * w); val out = FloatArray(3 * w * h)
            for (y in 0 until h) { DemosaicEngine.demosaicRow(mosaic, w, h, cfa, y, row); System.arraycopy(row, 0, out, 3 * w * y, 3 * w) }
            var se = 0.0; var n = 0
            for (y in 8 until h - 8) for (x in 8 until w - 8) for (c in 0..2) { val d = (out[3 * (y * w + x) + c] - rgb[3 * (y * w + x) + c]).toDouble(); se += d * d; n++ }
            val psnr = 10 * Math.log10(1.0 / (se / n))
            println("METRIC demosaic $cfa PSNR=%.1f dB".format(psnr))
            assertTrue("$cfa PSNR $psnr", psnr > 35.0)
        }
    }

    @Test fun borderPixelsAreFinite() {
        val w = 64; val h = 64
        val m = FloatArray(w * h) { 0.5f }
        val row = FloatArray(3 * w)
        for (y in listOf(0, 1, h - 2, h - 1)) {
            DemosaicEngine.demosaicRow(m, w, h, CfaPattern.RGGB, y, row)
            for (v in row) assertEquals(0.5, v.toDouble(), 1e-5) // flat field stays flat, border included
        }
    }
}

class DevelopTests {
    private fun flat(value: Float, w: Int = 128, h: Int = 128) = FloatArray(w * h) { value }

    @Test fun blackStaysBlackAndOutputIsMonotonic() {
        val meta = Synth.meta()
        var prev = -1
        for (v in listOf(0f, 0.02f, 0.1f, 0.3f, 0.6f, 0.95f)) {
            val img = RawDeveloper.develop(flat(v), 128, 128, meta, DevelopOptions(exposureEv = 0f, shadowLift = 0f))
            val g = (img.argb[64 * 128 + 64] shr 8) and 0xFF
            assertTrue("monotonic at $v: $g >= $prev", g >= prev); prev = g
        }
        val black = RawDeveloper.develop(flat(0f), 128, 128, meta, DevelopOptions(exposureEv = 0f, shadowLift = 0f))
        assertEquals(0, black.argb[64 * 128 + 64] and 0xFFFFFF)
    }

    @Test fun neutralGreyStaysNeutralAfterWhiteBalance() {
        // sensor sees grey as (R=1/2.0, G=1, B=1/1.6) * level; gains (2,1,1.6) must neutralise it; ccm rows sum to 1
        val meta = RawMeta(CfaPattern.RGGB, FloatArray(4), 1f, 1, 1, null, null, floatArrayOf(2f, 1f, 1.6f), floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f))
        val w = 128; val h = 128
        val m = FloatArray(w * h) { val c = CfaPattern.RGGB.colorAt(it % w, it / w); 0.3f * when (c) { 0 -> 1 / 2.0f; 2 -> 1 / 1.6f; else -> 1f } }
        val img = RawDeveloper.develop(m, w, h, meta, DevelopOptions(exposureEv = 0f, shadowLift = 0f))
        val p = img.argb[64 * w + 64]
        val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
        assertTrue("neutral grey r=$r g=$g b=$b", abs(r - g) <= 2 && abs(b - g) <= 2)
    }

    @Test fun shadowLiftBrightensDarkRegionsMoreThanBright() {
        val w = 128; val h = 128
        val m = FloatArray(w * h) { if (it % w < 64) 0.01f else 0.5f }
        val off = RawDeveloper.develop(m, w, h, Synth.meta(), DevelopOptions(exposureEv = 0f, shadowLift = 0f))
        val on = RawDeveloper.develop(m, w, h, Synth.meta(), DevelopOptions(exposureEv = 0f, shadowLift = 0.4f))
        val dark = { i: DevelopedImage -> (i.argb[64 * w + 20] shr 8) and 0xFF }
        val bright = { i: DevelopedImage -> (i.argb[64 * w + 110] shr 8) and 0xFF }
        assertTrue("dark ${dark(off)}->${dark(on)}", dark(on) > dark(off))
        assertTrue("bright barely changes ${bright(off)}->${bright(on)}", bright(on) - bright(off) <= 6)
    }

    @Test fun sixteenBitOutputMatchesEightBit() {
        val w = 128; val h = 128
        val img = RawDeveloper.develop(Synth.cleanMosaic(w, h, 0.0, 0.0), w, h, Synth.meta(), DevelopOptions(want16Bit = true))
        val rgb = img.rgb16!!
        for (i in listOf(100, 5000, 9000)) {
            val g8 = (img.argb[i] shr 8) and 0xFF
            val g16 = (rgb[i * 3 + 1].toInt() and 0xFFFF) / 257.0
            assertEquals(g8.toDouble(), g16, 1.0)
        }
    }
}

class ExportTests {
    @Test fun tiffHeaderAndPixelsRoundTrip() {
        val w = 5; val h = 3
        val px = ShortArray(w * h * 3) { (it * 4001).toShort() }
        val bos = ByteArrayOutputStream(); TiffWriter.writeRgb16(bos, w, h, px)
        val bb = ByteBuffer.wrap(bos.toByteArray()).order(ByteOrder.LITTLE_ENDIAN)
        assertEquals('I'.code, bb.get(0).toInt()); assertEquals(42, bb.getShort(2).toInt())
        val ifd = bb.getInt(4); val n = bb.getShort(ifd).toInt()
        val tags = HashMap<Int, Int>()
        for (i in 0 until n) { val o = ifd + 2 + 12 * i; val tag = bb.getShort(o).toInt() and 0xFFFF; val type = bb.getShort(o + 2).toInt(); tags[tag] = if (type == 3) bb.getShort(o + 8).toInt() and 0xFFFF else bb.getInt(o + 8) }
        assertEquals(w, tags[256]); assertEquals(h, tags[257]); assertEquals(3, tags[277]); assertEquals(2, tags[262])
        val bps = tags[258]!!; assertEquals(16, bb.getShort(bps).toInt()); assertEquals(16, bb.getShort(bps + 4).toInt())
        val start = tags[273]!!
        assertEquals(start + w * h * 6, bos.size())
        assertEquals(tags[279], w * h * 6)
        for (i in px.indices) assertEquals(px[i], bb.getShort(start + 2 * i))
        // tags must be strictly ascending (TIFF requirement)
        var prev = -1
        for (i in 0 until n) { val t = bb.getShort(ifd + 2 + 12 * i).toInt() and 0xFFFF; assertTrue(t > prev); prev = t }
    }

    @Test fun gray16Writes() {
        val bos = ByteArrayOutputStream(); TiffWriter.writeGray16(bos, 4, 4, ShortArray(16) { it.toShort() })
        assertEquals(16 * 2, bos.size() - 8 - (2 + 10 * 12 + 4) - 8)
    }
}

class BurstPlannerTests {
    private val px = 8_000_000L
    @Test fun fullBurstWhenPlentyOfMemory() = assertEquals(5, BurstPlanner.plan(5, px, 512L shl 20, 0))
    @Test fun burstShrinksWithLowMemory() {
        val n = BurstPlanner.plan(5, px, 230L shl 20, 0)
        assertTrue("n=$n", n in 1..4)
    }
    @Test fun refusesWhenEvenOneFrameDoesNotFit() = assertEquals(0, BurstPlanner.plan(5, px, 100L shl 20, 0))
    @Test fun thermalSevereLimitsBurstAndEmergencyRefuses() {
        assertEquals(3, BurstPlanner.plan(5, px, 512L shl 20, BurstPlanner.THERMAL_SEVERE))
        assertEquals(0, BurstPlanner.plan(5, px, 512L shl 20, BurstPlanner.THERMAL_EMERGENCY))
    }
    @Test fun tiffReservesMoreMemory() {
        assertTrue(BurstPlanner.plan(5, px, 260L shl 20, 0, withTiff = true) <= BurstPlanner.plan(5, px, 260L shl 20, 0, withTiff = false))
    }
}
