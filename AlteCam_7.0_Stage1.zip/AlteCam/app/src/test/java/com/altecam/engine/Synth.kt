package com.altecam.engine

import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Synthetic RAW generator for tests. The scene is a *continuous* function of position
 * so sub-pixel camera shifts are exact; sensor noise follows the Camera2 model
 * var = S*x + O (x normalised signal), i.e. the same model the engine consumes.
 * These are synthetic scenes — they validate the algorithms, not real-photo quality.
 */
object Synth {
    const val BLACK = 256f
    const val WHITE = 4095f
    const val S = 0.003f
    const val O = 1e-5f

    /** Linear scene colour in [0,1]; channel 0..2. Mix of smooth gradient, texture, soft edges. */
    fun scene(c: Int, x: Double, y: Double, brightness: Double = 1.0, movingBox: Boolean = false, bx: Double = 0.0): Double {
        val grad = 0.25 + 0.20 * sin(x / 97.0 + c) + 0.15 * sin(y / 71.0 - c * 0.7)
        val tex = 0.06 * sin(2 * PI * x / 9.0 + c) * sin(2 * PI * y / 11.0) + 0.05 * sin(2 * PI * (x + y) / 7.5)
        // soft vertical + diagonal edges (width ~1.5px)
        val edge = 0.18 * tanh((((x * 0.6 + y * 0.8) % 120.0) - 60.0) / 1.5)
        val checker = if ((((x / 16.0).toInt() + (y / 16.0).toInt()) and 1) == 0 && x > 300 && y > 200 && x < 420 && y < 330) 0.15 else 0.0
        var v = (grad + tex + edge + checker) * (0.8 + 0.2 * (c == 1).compareTo(false))
        if (movingBox && x > 200 + bx && x < 260 + bx && y > 120 && y < 180) v = 0.85
        return (v * brightness).coerceIn(0.01, 0.97)
    }

    fun meta(exposureNs: Long = 10_000_000L, iso: Int = 400, withNoiseProfile: Boolean = true, cfa: CfaPattern = CfaPattern.RGGB) =
        RawMeta(
            cfa, floatArrayOf(BLACK, BLACK, BLACK, BLACK), WHITE, exposureNs, iso,
            if (withNoiseProfile) floatArrayOf(S, S, S, S) else null,
            if (withNoiseProfile) floatArrayOf(O, O, O, O) else null,
            floatArrayOf(2.0f, 1.0f, 1.6f),
            floatArrayOf(1.6f, -0.4f, -0.2f, -0.3f, 1.5f, -0.2f, 0f, -0.5f, 1.5f)
        )

    /** Noise-free normalised mosaic (0..1 units) of the scene shifted by (sx, sy) camera pixels. */
    fun cleanMosaic(w: Int, h: Int, sx: Double, sy: Double, cfa: CfaPattern = CfaPattern.RGGB, brightness: Double = 1.0, box: Boolean = false, boxX: Double = 0.0): FloatArray {
        val out = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w)
            out[y * w + x] = scene(cfa.colorAt(x, y), x + sx, y + sy, brightness, box, boxX).toFloat()
        return out
    }

    /** Full RGB linear scene (for demosaic tests). */
    fun rgbScene(w: Int, h: Int): FloatArray {
        val o = FloatArray(3 * w * h)
        for (y in 0 until h) for (x in 0 until w) for (c in 0..2) o[3 * (y * w + x) + c] = scene(c, x.toDouble(), y.toDouble()).toFloat()
        return o
    }

    fun mosaicFromRgb(rgb: FloatArray, w: Int, h: Int, cfa: CfaPattern): FloatArray {
        val o = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) o[y * w + x] = rgb[3 * (y * w + x) + cfa.colorAt(x, y)]
        return o
    }

    /** Adds Poisson-Gaussian-like noise (var = S*x + O) and quantises to 16-bit raw counts. */
    fun toRaw(clean: FloatArray, w: Int, h: Int, meta: RawMeta, rng: Random, exposureGain: Float = 1f, blur: Int = 0): RawFrame {
        val data = ShortArray(w * h)
        val src = if (blur > 0) boxBlurX(clean, w, h, blur) else clean
        for (i in src.indices) {
            val x = (src[i] * exposureGain).coerceIn(0f, 1f)
            val var0 = S * x + O
            val n = rng.nextGaussian().toFloat() * sqrt(var0)
            val v = ((x + n).coerceIn(0f, 1f) * (WHITE - BLACK) + BLACK)
            data[i] = Math.round(v).toShort()
        }
        return RawFrame(w, h, data, meta)
    }

    private fun boxBlurX(a: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        // box blur over same-colour samples (step 2) to mimic horizontal motion blur
        val o = FloatArray(a.size)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f; var n = 0
            var k = -r
            while (k <= r) { val xx = x + 2 * k; if (xx in 0 until w) { s += a[y * w + xx]; n++ }; k++ }
            o[y * w + x] = s / n
        }
        return o
    }

    /** PSNR over the interior (peak = 1.0). */
    fun psnr(a: FloatArray, b: FloatArray, w: Int, h: Int, border: Int = 40): Double {
        var se = 0.0; var n = 0L
        for (y in border until h - border) for (x in border until w - border) {
            val d = (a[y * w + x] - b[y * w + x]).toDouble(); se += d * d; n++
        }
        val mse = se / n
        return if (mse <= 1e-12) 99.0 else 10 * log10(1.0 / mse)
    }

    fun psnrRaw(frame: RawFrame, clean: FloatArray, border: Int = 40): Double {
        val n = FloatArray(frame.data.size) { ((frame.data[it].toInt() and 0xFFFF) - BLACK) / (WHITE - BLACK) }
        return psnr(n, clean, frame.width, frame.height, border)
    }

    /** Old Alte Cam 6.0 algorithm (integer shift + per-pixel median), kept as a measured baseline. */
    fun legacyMedian(frames: List<ShortArray>, width: Int, height: Int): FloatArray {
        val shifts = ArrayList<IntArray>(); shifts.add(intArrayOf(0, 0))
        for (i in 1 until frames.size) shifts.add(legacyShift(frames[0], frames[i], width, height))
        val out = FloatArray(width * height)
        val values = IntArray(frames.size)
        for (y in 0 until height) for (x in 0 until width) {
            var count = 0
            for (i in frames.indices) {
                val sx = x + shifts[i][0]; val sy = y + shifts[i][1]
                if (sx in 0 until width && sy in 0 until height) values[count++] = frames[i][sy * width + sx].toInt() and 0xFFFF
            }
            values.sort(0, count)
            out[y * width + x] = (values[count / 2] - BLACK) / (WHITE - BLACK)
        }
        return out
    }

    private fun legacyShift(reference: ShortArray, candidate: ShortArray, width: Int, height: Int): IntArray {
        var best = Long.MAX_VALUE; var bdx = 0; var bdy = 0
        val radius = 8; val step = max(8, minOf(width, height) / 180); val margin = radius + step * 2
        for (dy in -radius..radius) for (dx in -radius..radius) {
            var score = 0L; var samples = 0
            var y = margin
            while (y < height - margin) {
                var x = margin
                while (x < width - margin) {
                    val a = reference[y * width + x].toInt() and 0xFFFF
                    val b = candidate[(y + dy) * width + (x + dx)].toInt() and 0xFFFF
                    val ar = reference[y * width + x + 2].toInt() and 0xFFFF
                    val br = candidate[(y + dy) * width + x + dx + 2].toInt() and 0xFFFF
                    score += abs((ar - a) - (br - b)).toLong(); samples++
                    x += step
                }
                y += step
            }
            if (samples > 0) { val nrm = score / samples; if (nrm < best) { best = nrm; bdx = dx; bdy = dy } }
        }
        return intArrayOf(bdx, bdy)
    }
}
