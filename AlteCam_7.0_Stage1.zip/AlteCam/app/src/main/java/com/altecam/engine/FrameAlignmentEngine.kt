package com.altecam.engine

import kotlin.math.abs
import kotlin.math.floor

/** Single-channel float image. */
class Plane(val w: Int, val h: Int, val d: FloatArray = FloatArray(w * h))

/**
 * Per-tile motion field, in half-resolution pixels (1 unit = 2 raw pixels, so
 * Bayer parity is always preserved when applied to the mosaic).
 */
class AlignmentField(
    val tilesX: Int,
    val tilesY: Int,
    /** tile size in half-res pixels */
    val tile: Int,
    val vx: FloatArray,
    val vy: FloatArray,
    /** best SAD per pixel for every tile (lower = better match) */
    val cost: FloatArray
) {
    fun medianCost(): Float {
        val c = cost.copyOf(); c.sort(); return c[c.size / 2]
    }
}

/**
 * Hierarchical tile-based block matching (coarse-to-fine pyramid), in the spirit of
 * the published HDR+ alignment (Hasinoff et al. 2016): L1 matching of tiles on a
 * Gaussian-like pyramid, each level seeded by the upsampled vector of its parent.
 * This is our own implementation, not Google's code.
 */
object FrameAlignmentEngine {

    /** Builds a half-resolution plane by averaging each 2x2 Bayer quad (CFA-neutral). */
    fun binHalf(frame: RawFrame, gain: Float): Plane {
        val m = frame.meta
        val w2 = frame.width / 2
        val h2 = frame.height / 2
        val out = Plane(w2, h2)
        val inv = gain / (m.whiteLevel - m.blackLevel.average().toFloat())
        val bl = m.blackLevel
        val src = frame.data
        val w = frame.width
        for (y in 0 until h2) {
            val r0 = 2 * y * w
            val r1 = r0 + w
            for (x in 0 until w2) {
                val i = 2 * x
                val s = (src[r0 + i].toInt() and 0xFFFF) - bl[0] +
                    (src[r0 + i + 1].toInt() and 0xFFFF) - bl[1] +
                    (src[r1 + i].toInt() and 0xFFFF) - bl[2] +
                    (src[r1 + i + 1].toInt() and 0xFFFF) - bl[3]
                out.d[y * w2 + x] = s * 0.25f * inv
            }
        }
        return out
    }

    fun downsample(p: Plane): Plane {
        val w = p.w / 2
        val h = p.h / 2
        val o = Plane(w, h)
        for (y in 0 until h) for (x in 0 until w) {
            val i = 2 * y * p.w + 2 * x
            o.d[y * w + x] = (p.d[i] + p.d[i + 1] + p.d[i + p.w] + p.d[i + p.w + 1]) * 0.25f
        }
        return o
    }

    fun buildPyramid(base: Plane, tile: Int): List<Plane> {
        val levels = ArrayList<Plane>()
        levels.add(base)
        var cur = base
        // stop when the coarsest level would have < 2 tiles in any direction
        while (levels.size < 4 && cur.w / 2 >= tile * 2 && cur.h / 2 >= tile * 2) {
            cur = downsample(cur); levels.add(cur)
        }
        return levels
    }

    /** Mean squared gradient — falls with motion blur, independent of absolute exposure after normalisation. */
    fun sharpness(plane: Plane): Float {
        var acc = 0.0
        var n = 0
        for (y in 0 until plane.h - 1) for (x in 0 until plane.w - 1) {
            val i = y * plane.w + x
            val gx = plane.d[i + 1] - plane.d[i]
            val gy = plane.d[i + plane.w] - plane.d[i]
            acc += (gx * gx + gy * gy).toDouble(); n++
        }
        return if (n == 0) 0f else (acc / n).toFloat()
    }

    fun align(ref: List<Plane>, alt: List<Plane>, tile: Int, subpixel: Boolean, cancel: CancelToken? = null): AlignmentField {
        require(ref.size == alt.size)
        val top = ref.size - 1
        var pvx = IntArray(0); var pvy = IntArray(0); var ptx = 0
        var field: AlignmentField? = null
        for (lvl in top downTo 0) {
            cancel?.throwIfCancelled()
            val r = ref[lvl]; val a = alt[lvl]
            val tx = (r.w + tile - 1) / tile
            val ty = (r.h + tile - 1) / tile
            val vx = IntArray(tx * ty); val vy = IntArray(tx * ty)
            val cost = FloatArray(tx * ty)
            val radius = if (lvl == top) 4 else 2
            for (j in 0 until ty) for (i in 0 until tx) {
                var sx = 0; var sy = 0
                if (lvl != top) {
                    val pi = (i / 2).coerceAtMost(ptx - 1)
                    val pj = (j / 2).coerceAtMost(pvx.size / ptx - 1)
                    sx = pvx[pj * ptx + pi] * 2; sy = pvy[pj * ptx + pi] * 2
                }
                var best = Float.MAX_VALUE; var bx = sx; var by = sy
                for (dy in -radius..radius) for (dx in -radius..radius) {
                    val cx = sx + dx; val cy = sy + dy
                    val c = tileSad(r, a, i * tile, j * tile, tile, cx, cy)
                    if (c == Float.MAX_VALUE) continue
                    // small multiplicative penalty keeps vectors stable in flat/noisy areas
                    val pen = c * (1f + 0.02f * (abs(dx) + abs(dy)))
                    if (pen < best) { best = pen; bx = cx; by = cy }
                }
                if (best == Float.MAX_VALUE) { bx = sx; by = sy; best = 0f }
                vx[j * tx + i] = bx; vy[j * tx + i] = by
                cost[j * tx + i] = tileSad(r, a, i * tile, j * tile, tile, bx, by).let { if (it == Float.MAX_VALUE) best else it }
            }
            if (lvl == 0) {
                val fx = FloatArray(tx * ty); val fy = FloatArray(tx * ty)
                for (j in 0 until ty) for (i in 0 until tx) {
                    val k = j * tx + i
                    fx[k] = vx[k].toFloat(); fy[k] = vy[k].toFloat()
                    if (subpixel && cost[k] > 0f) {
                        // refine on a 0.25 px grid with bilinearly interpolated SAD
                        var bestC = Float.MAX_VALUE; var bfx = 0f; var bfy = 0f
                        for (qy in -2..2) for (qx in -2..2) {
                            val ox = qx * 0.25f; val oy = qy * 0.25f
                            val c = tileSadFrac(r, a, i * tile, j * tile, tile, vx[k] + ox, vy[k] + oy)
                            if (c < bestC * (1f + 0.002f * (abs(qx) + abs(qy)))) { bestC = c; bfx = ox; bfy = oy }
                        }
                        fx[k] += bfx; fy[k] += bfy
                    }
                }
                field = AlignmentField(tx, ty, tile, fx, fy, cost)
            }
            pvx = vx; pvy = vy; ptx = tx
        }
        return field!!
    }

    /** Like [tileSad] but the candidate offset is fractional (bilinear sampling of [a]). */
    private fun tileSadFrac(r: Plane, a: Plane, x0: Int, y0: Int, t: Int, dx: Float, dy: Float): Float {
        val ix = floor(dx.toDouble()).toInt(); val iy = floor(dy.toDouble()).toInt()
        val fx = dx - ix; val fy = dy - iy
        val xs = maxOf(x0, -ix, 0); val xe = minOf(x0 + t, r.w, a.w - ix - 1)
        val ys = maxOf(y0, -iy, 0); val ye = minOf(y0 + t, r.h, a.h - iy - 1)
        if (xe <= xs || ye <= ys) return Float.MAX_VALUE
        val area = (xe - xs) * (ye - ys)
        var s = 0f
        for (y in ys until ye) {
            var ri = y * r.w + xs
            var ai = (y + iy) * a.w + xs + ix
            for (x in xs until xe) {
                val top = a.d[ai] + (a.d[ai + 1] - a.d[ai]) * fx
                val bot = a.d[ai + a.w] + (a.d[ai + a.w + 1] - a.d[ai + a.w]) * fx
                s += abs(r.d[ri] - (top + (bot - top) * fy)); ri++; ai++
            }
        }
        return s / area
    }

    /** Mean absolute difference over the in-bounds part of a tile; MAX_VALUE if <50% in bounds. */
    private fun tileSad(r: Plane, a: Plane, x0: Int, y0: Int, t: Int, dx: Int, dy: Int): Float {
        val xs = maxOf(x0, -dx, 0); val xe = minOf(x0 + t, r.w, a.w - dx)
        val ys = maxOf(y0, -dy, 0); val ye = minOf(y0 + t, r.h, a.h - dy)
        if (xe <= xs || ye <= ys) return Float.MAX_VALUE
        val area = (xe - xs) * (ye - ys)
        if (area * 2 < minOf(t, r.w - x0) * minOf(t, r.h - y0)) return Float.MAX_VALUE
        var s = 0f
        for (y in ys until ye) {
            var ri = y * r.w + xs
            var ai = (y + dy) * a.w + xs + dx
            for (x in xs until xe) { s += abs(r.d[ri] - a.d[ai]); ri++; ai++ }
        }
        return s / area
    }

    /** Convenience: floor to int with correct negative handling. */
    internal fun ifloor(v: Float): Int = floor(v.toDouble()).toInt()
}
