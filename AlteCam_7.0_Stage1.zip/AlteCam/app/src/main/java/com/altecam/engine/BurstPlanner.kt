package com.altecam.engine

/**
 * Decides how many frames a burst may contain given memory and thermal state, so the
 * pipeline degrades quality instead of crashing (OutOfMemoryError) or overheating.
 * Pure function => unit-testable.
 */
object BurstPlanner {
    /** Android PowerManager thermal status values (API 29+). */
    const val THERMAL_SEVERE = 3
    const val THERMAL_EMERGENCY = 5

    /** Heap bytes per pixel that stay allocated regardless of frame count (fused float + ARGB + optional 16-bit RGB + bitmap/encode slack). */
    private const val FIXED_BYTES_PER_PIXEL = 4 + 4 + 4 + 4
    private const val FIXED_BYTES_PER_PIXEL_TIFF = FIXED_BYTES_PER_PIXEL + 6

    /** Heap bytes per pixel per frame: 16-bit copy (2) + half-res alignment pyramid (~0.67). */
    private const val FRAME_BYTES_PER_PIXEL = 2.7

    /**
     * @param requested desired burst length
     * @param pixels pixels per RAW frame
     * @param freeHeapBytes heap the app may still use (maxMemory - used)
     * @param thermalStatus PowerManager thermal status, 0 if unknown
     * @return frames to capture; 0 = refuse (device too hot / not enough memory even for one frame)
     */
    fun plan(requested: Int, pixels: Long, freeHeapBytes: Long, thermalStatus: Int, withTiff: Boolean = false): Int {
        if (requested <= 0) return 0
        if (thermalStatus >= THERMAL_EMERGENCY) return 0
        val fixed = pixels * (if (withTiff) FIXED_BYTES_PER_PIXEL_TIFF else FIXED_BYTES_PER_PIXEL)
        val budget = freeHeapBytes * 0.85 - fixed
        if (budget < pixels * FRAME_BYTES_PER_PIXEL) return 0
        val byMemory = (budget / (pixels * FRAME_BYTES_PER_PIXEL)).toInt()
        var n = minOf(requested, byMemory)
        if (thermalStatus >= THERMAL_SEVERE) n = minOf(n, 3)
        return n.coerceAtLeast(1)
    }
}
