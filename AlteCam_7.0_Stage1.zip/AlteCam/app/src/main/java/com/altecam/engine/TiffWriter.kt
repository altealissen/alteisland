package com.altecam.engine

import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Minimal baseline TIFF writer: uncompressed, little-endian, single strip. */
object TiffWriter {

    /** 16-bit RGB, interleaved. Values are sRGB-encoded (no ICC profile embedded; viewers assume sRGB). */
    fun writeRgb16(out: OutputStream, width: Int, height: Int, rgb16: ShortArray) {
        require(rgb16.size == width * height * 3)
        writeTiff(out, width, height, 3, 16, rgb16)
    }

    /** 16-bit grayscale, e.g. a raw Bayer mosaic dump. Not a DNG. */
    fun writeGray16(out: OutputStream, width: Int, height: Int, gray: ShortArray) {
        require(gray.size == width * height)
        writeTiff(out, width, height, 1, 16, gray)
    }

    private fun writeTiff(out: OutputStream, w: Int, h: Int, spp: Int, bits: Int, data: ShortArray) {
        val entries = 10
        val ifdOffset = 8
        val ifdSize = 2 + entries * 12 + 4
        val bpsOffset = ifdOffset + ifdSize                  // BitsPerSample array (spp shorts) lives after the IFD
        val dataOffset = bpsOffset + 8
        val dataBytes = w.toLong() * h * spp * 2
        require(dataOffset + dataBytes < 0xFFFFFFFFL) { "TIFF too large" }

        val head = ByteBuffer.allocate(dataOffset).order(ByteOrder.LITTLE_ENDIAN)
        head.put('I'.code.toByte()).put('I'.code.toByte()).putShort(42).putInt(ifdOffset)
        head.putShort(entries.toShort())
        fun entry(tag: Int, type: Int, count: Int, value: Int) {
            head.putShort(tag.toShort()).putShort(type.toShort()).putInt(count)
            if (type == 3 && count == 1) { head.putShort(value.toShort()).putShort(0) } else head.putInt(value)
        }
        entry(256, 4, 1, w)                                   // ImageWidth
        entry(257, 4, 1, h)                                   // ImageLength
        if (spp == 1) entry(258, 3, 1, bits) else entry(258, 3, spp, bpsOffset)
        entry(259, 3, 1, 1)                                   // Compression: none
        entry(262, 3, 1, if (spp == 1) 1 else 2)              // Photometric: BlackIsZero / RGB
        entry(273, 4, 1, dataOffset)                          // StripOffsets
        entry(277, 3, 1, spp)                                 // SamplesPerPixel
        entry(278, 4, 1, h)                                   // RowsPerStrip
        entry(279, 4, 1, dataBytes.toInt())                   // StripByteCounts
        entry(284, 3, 1, 1)                                   // PlanarConfiguration: chunky
        head.putInt(0)                                        // next IFD
        for (i in 0 until 4) head.putShort(if (i < spp) bits.toShort() else 0)
        out.write(head.array(), 0, head.position())

        val rowBuf = ByteBuffer.allocate(w * spp * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (y in 0 until h) {
            rowBuf.clear()
            val base = y * w * spp
            for (i in 0 until w * spp) rowBuf.putShort(data[base + i])
            out.write(rowBuf.array(), 0, rowBuf.position())
        }
        out.flush()
    }
}
