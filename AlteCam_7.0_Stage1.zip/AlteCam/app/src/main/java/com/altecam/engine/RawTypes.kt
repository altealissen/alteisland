package com.altecam.engine

import java.util.concurrent.CancellationException

/**
 * Alte Computational Photography Engine — platform-independent data types.
 * Nothing in this package depends on android.*, so it is unit-testable on the JVM.
 */

/** Bayer layout. Index into [colors] is (y&1)*2 + (x&1); value 0=R, 1=G, 2=B. */
enum class CfaPattern(val colors: IntArray) {
    RGGB(intArrayOf(0, 1, 1, 2)),
    GRBG(intArrayOf(1, 0, 2, 1)),
    GBRG(intArrayOf(1, 2, 0, 1)),
    BGGR(intArrayOf(2, 1, 1, 0));

    fun colorAt(x: Int, y: Int): Int = colors[((y and 1) shl 1) or (x and 1)]

    companion object {
        /** Maps CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT (0..3). */
        fun fromCamera2(value: Int): CfaPattern = when (value) {
            0 -> RGGB
            1 -> GRBG
            2 -> GBRG
            3 -> BGGR
            else -> throw IllegalArgumentException("Unsupported CFA arrangement: $value")
        }
    }
}

/**
 * Per-frame RAW metadata. Arrays indexed by CFA position (y&1)*2 + (x&1).
 *
 * @property blackLevel black level per CFA position in raw counts.
 * @property whiteLevel saturation level in raw counts.
 * @property noiseS / noiseO Camera2 SENSOR_NOISE_PROFILE per position:
 *   var(x) = S*x + O, where x is the black-subtracted signal normalised to 0..1.
 *   Null if the device does not report it (engine then estimates noise from data).
 * @property wbGains R,G,B multipliers (Camera2 COLOR_CORRECTION_GAINS).
 * @property ccm 3x3 row-major, white-balanced sensor RGB -> linear sRGB (COLOR_CORRECTION_TRANSFORM).
 */
class RawMeta(
    val cfa: CfaPattern,
    val blackLevel: FloatArray,
    val whiteLevel: Float,
    val exposureTimeNs: Long,
    val iso: Int,
    val noiseS: FloatArray? = null,
    val noiseO: FloatArray? = null,
    val wbGains: FloatArray = floatArrayOf(1f, 1f, 1f),
    val ccm: FloatArray? = null
) {
    init {
        require(blackLevel.size == 4) { "blackLevel must have 4 entries" }
        require(whiteLevel > blackLevel.max()) { "whiteLevel must exceed black level" }
        require(noiseS == null || noiseS.size == 4)
        require(noiseO == null || noiseO.size == 4)
        require(wbGains.size == 3)
        require(ccm == null || ccm.size == 9)
    }

    /** Relative exposure (time * sensitivity); frames are normalised to a common value. */
    val exposureProduct: Double get() = exposureTimeNs.toDouble() * iso.toDouble()
}

/** One 16-bit Bayer mosaic. [data] holds unsigned 16-bit samples (read with `and 0xFFFF`). */
class RawFrame(val width: Int, val height: Int, val data: ShortArray, val meta: RawMeta) {
    init {
        require(width >= 2 && height >= 2 && width % 2 == 0 && height % 2 == 0) { "RAW size must be even" }
        require(data.size == width * height) { "RAW data size mismatch" }
    }
}

fun interface ProgressListener {
    /** @param stage human-readable stage ("Aligning", "Merging", ...); @param fraction 0..1 within stage */
    fun onProgress(stage: String, fraction: Float)
}

/** Cooperative cancellation. Long loops poll [throwIfCancelled]. */
class CancelToken {
    @Volatile
    var cancelled: Boolean = false
        private set

    fun cancel() { cancelled = true }
    fun throwIfCancelled() { if (cancelled) throw CancellationException("Processing cancelled") }
}

class FusionOptions(
    /** Use at most this many frames (extra frames are ignored, earliest first). */
    val maxFrames: Int = 16,
    /** Alignment tile size in half-resolution pixels (32 raw pixels at 16). */
    val tileSize: Int = 16,
    /** Sub-pixel alignment + bilinear same-colour resampling. */
    val subpixel: Boolean = true,
    /** Frame discarded if its sharpness < ratio * best sharpness (motion blur). */
    val sharpnessRejectRatio: Float = 0.6f,
    /** Frame discarded if its alignment error exceeds this multiple of the best alt frame's. */
    val alignmentRejectRatio: Float = 4.0f,
    /** Higher = more aggressive temporal averaging, lower = more ghost protection. */
    val mergeTolerance: Float = 1.0f,
    val threads: Int = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
)

class FusionResult(
    val width: Int,
    val height: Int,
    /** Fused Bayer mosaic, black-subtracted and normalised so that 1.0 = reference white. */
    val bayer: FloatArray,
    val meta: RawMeta,
    val referenceIndex: Int,
    val usedFrames: List<Int>,
    /** frame index -> reason */
    val discarded: Map<Int, String>,
    val elapsedMs: Long,
    /** Mean per-pixel weight given to non-reference frames (0..1); low = lots of ghost rejection. */
    val meanAltWeight: Float
)
